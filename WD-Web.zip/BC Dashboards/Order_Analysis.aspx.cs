﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Order_Analysis : System.Web.UI.Page
{
   
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Username"] == null && Session["Password"] == null && Session["WHuser"] == null)
        {
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "myscript", "window.close();", true); return;
        }
    }

    protected void Timer1_Tick(object sender, EventArgs e)
    {

        
        if (Session["EmployeeAnalysis"] as string == "true")
            Response.Redirect("Employee_Analysis.aspx");
        else if (Session["BatchAnalysis"] as string == "true")
            Response.Redirect("Batch_Analysis.aspx");
        else if (Session["PickCartAnalysis"] as string == "true")
            Response.Redirect("PickCart_Analysis.aspx");
        else if (Session["PickStatus"] as string == "true")
            Response.Redirect("PickStatus.aspx");
        else if (Session["PickedStatus"] as string == "true")
            Response.Redirect("PickedStatus.aspx");
        else if (Session["ShippingStatus"] as string == "true")
            Response.Redirect("OrdersShipping.aspx");
        else if (Session["ShippedStatus"] as string == "true")
            Response.Redirect("OrdersShipped.aspx");
        else if (Session["PickPerformance"] as string == "true")
            Response.Redirect("PickPerformance.aspx");
        else if (Session["PackPerformance"] as string == "true")
            Response.Redirect("PackPerformance.aspx");
        else if (Session["PickedGraph"] as string == "true")
            Response.Redirect("PickedStatusGraph.aspx");
        else if (Session["ShippedGraph"] as string == "true")
            Response.Redirect("ShippedStatusGraph.aspx");
        else if (Session["DailyPick"] as string == "true")
            Response.Redirect("Daily_Picked_Details.aspx");
        else if (Session["DailyShip"] as string == "true")
            Response.Redirect("Daily_Shipped_Details.aspx");
        else if (Session["MonthlyPick"] as string == "true")
            Response.Redirect("Montyly_Picked_Details.aspx");
        else if (Session["MonthlyShip"] as string == "true")
            Response.Redirect("Monthly_Shipped_Details.aspx");
        else
            Response.Redirect("Order_Analysis.aspx");

    }

}