﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class SlideShow_Select : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Username"] == null && Session["Password"] == null && Session["WHuser"] == null)
        {
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "myscript", "window.close();", true); return;
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        //Page.ClientScript.RegisterStartupScript(this.GetType(), "OpenWindow", @"window.open('\PickStatus.aspx','_newtab');", true);
        //Response.Write("OrdersShipping.aspx");
        Session["PickStatus"] = null;
        Session["PickedStatus"] = null;
        Session["ShippingStatus"] = null;
        Session["ShippedStatus"] = null;
        Session["PickedGraph"] = null;
        Session["ShippedGraph"] = null;
        Session["PickPerformance"] = null;
        Session["PackPerformance"] = null;

        Session["DailyPick"] = null;
        Session["DailyShip"] = null;
        Session["MonthlyPick"] = null;
        Session["MonthlyShip"] = null;

        Session["OrderAnalysis"] = null;
        Session["EmployeeAnalysis"] = null;
        Session["BatchAnalysis"] = null;
        Session["PickCartAnalysis"] = null;

        if (CheckBox1.Checked)
            Session["PickStatus"] = CheckBox1.Checked.ToString().ToLower();
        if (CheckBox2.Checked)
            Session["PickedStatus"] = CheckBox2.Checked.ToString().ToLower();
        if (CheckBox3.Checked)
            Session["ShippingStatus"] = CheckBox3.Checked.ToString().ToLower();
        if (CheckBox4.Checked)
            Session["ShippedStatus"] = CheckBox4.Checked.ToString().ToLower();
        if (CheckBox5.Checked)
            Session["PickedGraph"] = CheckBox5.Checked.ToString().ToLower();
        if (CheckBox6.Checked)
            Session["ShippedGraph"] = CheckBox6.Checked.ToString().ToLower();
        if (CheckBox7.Checked)
            Session["PickPerformance"] = CheckBox7.Checked.ToString().ToLower();
        if (CheckBox8.Checked)
            Session["PackPerformance"] = CheckBox8.Checked.ToString().ToLower();

        if (chkdailypick.Checked)
            Session["DailyPick"] = chkdailypick.Checked.ToString().ToLower();
        if (chkdailyship.Checked)
            Session["DailyShip"] = chkdailyship.Checked.ToString().ToLower();
        if (chkmonthlypick.Checked)
            Session["MonthlyPick"] = chkmonthlypick.Checked.ToString().ToLower();
        if (chkmonthlyship.Checked)
            Session["MonthlyShip"] = chkmonthlyship.Checked.ToString().ToLower();

        if (chkOA.Checked)
            Session["OrderAnalysis"] = chkOA.Checked.ToString().ToLower();

        if (chkEA.Checked)
            Session["EmployeeAnalysis"] = chkEA.Checked.ToString().ToLower();
        if (CheckBox10.Checked)
            Session["BatchAnalysis"] = CheckBox10.Checked.ToString().ToLower();
        //if (CheckBox11.Checked)
        //    Session["PickCartAnalysis"] = CheckBox10.Checked.ToString().ToLower();

        if (Session["PickStatus"] as string == "true")
            Response.Redirect("PickStatus.aspx");
        else if (Session["PickedStatus"] as string == "true")
            Response.Redirect("PickedStatus.aspx");
        else if (Session["ShippingStatus"] as string == "true")
            Response.Redirect("OrdersShipping.aspx");
        else if (Session["ShippedStatus"] as string == "true")
            Response.Redirect("OrdersShipped.aspx");
        else if (Session["PickedGraph"] as string == "true")
            Response.Redirect("PickedStatusGraph.aspx");
        else if (Session["ShippedGraph"] as string == "true")
            Response.Redirect("ShippedStatusGraph.aspx");
        else if (Session["PickPerformance"] as string == "true")
            Response.Redirect("PickPerformance.aspx");
        else if (Session["PackPerformance"] as string == "true")
            Response.Redirect("PackPerformance.aspx");
        else if (Session["DailyPick"] as string == "true")
            Response.Redirect("Daily_Picked_Details.aspx");
        else if (Session["DailyShip"] as string == "true")
            Response.Redirect("Daily_Shipped_Details.aspx");
        else if (Session["MonthlyPick"] as string == "true")
            Response.Redirect("Montyly_Picked_Details.aspx");
        else if (Session["MonthlyShip"] as string == "true")
            Response.Redirect("Monthly_Shipped_Details.aspx");
        else if (Session["OrderAnalysis"] as string == "true")
            Response.Redirect("Order_Analysis.aspx");
        else if (Session["EmployeeAnalysis"] as string == "true")
            Response.Redirect("Employee_Analysis.aspx");
        else if (Session["BatchAnalysis"] as string == "true")
            Response.Redirect("Batch_Analysis.aspx");
        else if (Session["PickCartAnalysis"] as string == "true")
            Response.Redirect("PickCart_Analysis.aspx");

    }

    protected void CheckBox9_CheckedChanged(object sender, EventArgs e)
    {
        if (CheckBox9.Checked)
        {
            CheckBox1.Checked = true;
            CheckBox2.Checked = true;
            CheckBox3.Checked = true;
            CheckBox4.Checked = true;
            CheckBox5.Checked = true;
            CheckBox6.Checked = true;
            CheckBox7.Checked = true;
            CheckBox8.Checked = true;
            chkdailypick.Checked = true;
            chkdailyship.Checked = true;
            chkmonthlypick.Checked = true;
            chkmonthlyship.Checked = true;
            chkOA.Checked = true;
            chkEA.Checked = true;
            CheckBox10.Checked = true;
            //CheckBox11.Checked = true;

        }
        else
        {
            CheckBox1.Checked = false;
            CheckBox2.Checked = false;
            CheckBox3.Checked = false;
            CheckBox4.Checked = false;
            CheckBox5.Checked = false;
            CheckBox6.Checked = false;
            CheckBox7.Checked = false;
            CheckBox8.Checked = false;
            chkdailypick.Checked = false;
            chkdailyship.Checked = false;
            chkmonthlypick.Checked = false;
            chkmonthlyship.Checked = false;
            chkOA.Checked = false;
            chkEA.Checked = false;
            CheckBox10.Checked = false;
            //CheckBox11.Checked = false;
        }
    }

}