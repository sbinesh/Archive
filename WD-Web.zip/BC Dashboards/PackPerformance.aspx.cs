﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WHDB;

public partial class PackPerformance : System.Web.UI.Page
{
    WarehouseDashboard objservice = new WarehouseDashboard();
    int statusP = 0;
    PickedPerformanceDashboardRoot1 PPDR = new PickedPerformanceDashboardRoot1();

    string username, password;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Username"] != null && Session["Password"] != null && Session["WHuser"] != null)
        {
            username = Session["Username"].ToString();
            password = Session["Password"].ToString();
        }
        else
        { ScriptManager.RegisterStartupScript(Page, this.GetType(), "myscript", "window.close();", true); return; }

        objservice.Credentials = new System.Net.NetworkCredential(username, password, System.Configuration.ConfigurationManager.AppSettings["Domain"]);
        if (!IsPostBack)
        {
            BindData();
        }
    }

    protected void Timer1_Tick(object sender, EventArgs e)
    {
        if (Session["PickedGraph"] as string == "true")
            Response.Redirect("PickedStatusGraph.aspx");
        else if (Session["ShippedGraph"] as string == "true")
            Response.Redirect("ShippedStatusGraph.aspx");
        else if (Session["DailyPick"] as string == "true")
            Response.Redirect("Daily_Picked_Details.aspx");
        else if (Session["DailyShip"] as string == "true")
            Response.Redirect("Daily_Shipped_Details.aspx");
        else if (Session["MonthlyPick"] as string == "true")
            Response.Redirect("Montyly_Picked_Details.aspx");
        else if (Session["MonthlyShip"] as string == "true")
            Response.Redirect("Monthly_Shipped_Details.aspx");
        else if (Session["OrderAnalysis"] as string == "true")
            Response.Redirect("Order_Analysis.aspx");
        else if (Session["EmployeeAnalysis"] as string == "true")
            Response.Redirect("Employee_Analysis.aspx");
        else if (Session["BatchAnalysis"] as string == "true")
            Response.Redirect("Batch_Analysis.aspx");
        else if (Session["PickCartAnalysis"] as string == "true")
            Response.Redirect("PickCart_Analysis.aspx");
        else if (Session["PickStatus"] as string == "true")
            Response.Redirect("PickStatus.aspx");
        else if (Session["PickedStatus"] as string == "true")
            Response.Redirect("PickedStatus.aspx");
        else if (Session["ShippingStatus"] as string == "true")
            Response.Redirect("OrdersShipping.aspx");
        else if (Session["ShippedStatus"] as string == "true")
            Response.Redirect("OrdersShipped.aspx");
        else if (Session["PickPerformance"] as string == "true")
            Response.Redirect("PickPerformance.aspx");
        else
            Response.Redirect("PackPerformance.aspx");
    }

    private void BindData()
    {
        try
        {
            string date = System.DateTime.Now.ToString("MM/dd/yy");
            //date = "01/11/16";

            objservice.PackedPerformance(date, ref PPDR, ref statusP);

            if (Session["pack_location"] != null)
                txtLocation.Text = Session["pack_location"].ToString();
            //else
            //   txtLocation.Text = System.Configuration.ConfigurationManager.AppSettings["loc1"];

            bool isFlag = false;
            int tempCount = 0;

            for (int i = 0; i < PPDR.PickedPerformanceDashboard.Count(); i++)
            {
                if (string.IsNullOrEmpty(txtLocation.Text))
                {
                    if (PPDR.PickedPerformanceDashboard[i].Location == System.Configuration.ConfigurationManager.AppSettings["loc1"])
                    {
                        isFlag = true;

                        string[] temp = new string[] { };
                        string temp1 = "";
                        if (PPDR.PickedPerformanceDashboard[i].UserID.Contains('\\'))
                        {
                            temp = PPDR.PickedPerformanceDashboard[i].UserID.Split('\\');
                            temp1 = temp[1];
                        }
                        else
                            temp1 = PPDR.PickedPerformanceDashboard[i].UserID;

                        if (!string.IsNullOrEmpty(temp1) && PPDR.PickedPerformanceDashboard[i].NoOfPacked != 0)
                        {
                            switch (tempCount)
                            {
                                case 0:
                                    Label1.Text = temp1;
                                    Label2.Text = PPDR.PickedPerformanceDashboard[i].NoOfPacked.ToString();
                                    div1.Visible = true; tempCount++;
                                    break;
                                case 1:
                                    Label3.Text = temp1;
                                    Label4.Text = PPDR.PickedPerformanceDashboard[i].NoOfPacked.ToString();
                                    div2.Visible = true; tempCount++;
                                    break;
                                case 2:
                                    Label5.Text = temp1;
                                    Label6.Text = PPDR.PickedPerformanceDashboard[i].NoOfPacked.ToString();
                                    div3.Visible = true; tempCount++;
                                    break;
                                case 3:
                                    Label7.Text = temp1;
                                    Label8.Text = PPDR.PickedPerformanceDashboard[i].NoOfPacked.ToString();
                                    div4.Visible = true; tempCount++;
                                    break;
                                case 4:
                                    Label9.Text = temp1;
                                    Label10.Text = PPDR.PickedPerformanceDashboard[i].NoOfPacked.ToString();
                                    div5.Visible = true; tempCount++;
                                    break;
                                case 5:
                                    Label11.Text = temp1;
                                    Label12.Text = PPDR.PickedPerformanceDashboard[i].NoOfPacked.ToString();
                                    div6.Visible = true; tempCount++;
                                    break;
                            }
                        }
                        else
                        {
                            div1.Visible = false;
                            div2.Visible = false;
                            div3.Visible = false;
                            div4.Visible = false;
                            div5.Visible = false;
                            div6.Visible = false;
                            return;
                        }
                    }
                }
                else if (PPDR.PickedPerformanceDashboard[i].Location == txtLocation.Text)
                {

                    isFlag = true;

                    string[] temp = new string[] { };
                    string temp1 = "";
                    if (PPDR.PickedPerformanceDashboard[i].UserID.Contains('\\'))
                    {
                        temp = PPDR.PickedPerformanceDashboard[i].UserID.Split('\\');
                        temp1 = temp[1];
                    }
                    else
                        temp1 = PPDR.PickedPerformanceDashboard[i].UserID;

                    if (!string.IsNullOrEmpty(temp1) && PPDR.PickedPerformanceDashboard[i].NoOfPacked != 0)
                    {
                        switch (tempCount)
                        {
                            case 0:
                                Label1.Text = temp1;
                                Label2.Text = PPDR.PickedPerformanceDashboard[i].NoOfPacked.ToString();
                                div1.Visible = true; tempCount++;
                                break;
                            case 1:
                                Label3.Text = temp1;
                                Label4.Text = PPDR.PickedPerformanceDashboard[i].NoOfPacked.ToString();
                                div2.Visible = true; tempCount++;
                                break;
                            case 2:
                                Label5.Text = temp1;
                                Label6.Text = PPDR.PickedPerformanceDashboard[i].NoOfPacked.ToString();
                                div3.Visible = true; tempCount++;
                                break;
                            case 3:
                                Label7.Text = temp1;
                                Label8.Text = PPDR.PickedPerformanceDashboard[i].NoOfPacked.ToString();
                                div4.Visible = true; tempCount++;
                                break;
                            case 4:
                                Label9.Text = temp1;
                                Label10.Text = PPDR.PickedPerformanceDashboard[i].NoOfPacked.ToString();
                                div5.Visible = true; tempCount++;
                                break;
                            case 5:
                                Label11.Text = temp1;
                                Label12.Text = PPDR.PickedPerformanceDashboard[i].NoOfPacked.ToString();
                                div6.Visible = true; tempCount++;
                                break;
                        }
                    }
                    else
                    {
                        div1.Visible = false;
                        div2.Visible = false;
                        div3.Visible = false;
                        div4.Visible = false;
                        div5.Visible = false;
                        div6.Visible = false;
                        return;
                    }
                }
            }

            if (isFlag)
            {
                switch (tempCount)
                {
                    case 0:
                        div1.Visible = false;
                        div2.Visible = false;
                        div3.Visible = false;
                        div4.Visible = false;
                        div5.Visible = false;
                        div6.Visible = false;
                        break;
                    case 1:
                        div2.Visible = false;
                        div3.Visible = false;
                        div4.Visible = false;
                        div5.Visible = false;
                        div6.Visible = false;
                        break;
                    case 2:
                        div3.Visible = false;
                        div4.Visible = false;
                        div5.Visible = false;
                        div6.Visible = false;
                        break;
                    case 3:
                        div4.Visible = false;
                        div5.Visible = false;
                        div6.Visible = false;
                        break;
                    case 4:
                        div5.Visible = false;
                        div6.Visible = false;
                        break;
                    case 5:
                        div6.Visible = false;
                        break;
                }
            }
            else
            {
                div1.Visible = false;
                div2.Visible = false;
                div3.Visible = false;
                div4.Visible = false;
                div5.Visible = false;
                div6.Visible = false;
            }



            // DateTime firstDay = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
            // //first day of next month minus one day
            // DateTime lastDay = firstDay.AddMonths(1).AddDays(-1);
            // //See: http://msdn.microsoft.com/en-us/library/system.datetime.addmonths.aspx
            // Response.Write(firstDay.Date.ToShortDateString() + "<br />");
            // Response.Write(lastDay.Date.ToShortDateString() + "<br />");

        }
        catch (System.Web.Services.Protocols.SoapException sx)
        {
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.alert('" + sx.Message + "');", true);
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.alert('" + ex.Message + "');", true);
        }
    }

    protected void txtLocation_TextChanged(object sender, EventArgs e)
    {
        Session["pack_location"] = txtLocation.Text;
        Response.Redirect("PackPerformance.aspx");
    }

}