﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WHDB;
using System.Data;

public partial class Employee_Analysis : System.Web.UI.Page
{

    WarehouseDashboard objservice = new WarehouseDashboard();
    int statusP = 0;
    string dateP = "";
    PickedPerformanceDashboardRoot objPPD = new PickedPerformanceDashboardRoot();

    List<WEmployee> objList = new List<WEmployee>();

    string username, password;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Username"] != null && Session["Password"] != null && Session["WHuser"] != null)
        {
            username = Session["Username"].ToString();
            password = Session["Password"].ToString();
        }
        else
        { ScriptManager.RegisterStartupScript(Page, this.GetType(), "myscript", "window.close();", true); return; }

        objservice.Credentials = new System.Net.NetworkCredential(username, password, System.Configuration.ConfigurationManager.AppSettings["Domain"]);
        if (!IsPostBack)
            BindData();
        /*else
        {
            if (Session["location"] != null)
                txtLocation.Text = Session["location"].ToString();
            if (Session["date"] != null)
                txtdate.Text = Session["date"].ToString();
        }*/
    }

    private void BindData()
    {
        try
        {
            dateP = System.DateTime.Now.ToString("MM/dd/yy");
            //dateP = "01/21/2016";
            if (Session["location"] != null)
                txtLocation.Text = Session["location"].ToString();

            if (Session["date"] != null)
            {
                dateP = Session["date"].ToString();
                txtdate.Text = dateP;
                objservice.WarehouseEmployeeAnalysis(dateP, ref objPPD, ref statusP);
            }
            else
                objservice.WarehouseEmployeeAnalysis(dateP, ref objPPD, ref statusP);
            string[] User;
            string User_ID = "";

            DataTable dt = new DataTable();

            dt.Columns.AddRange(
                            new DataColumn[8] 
                            { 
                            new DataColumn("UserID", typeof(string)),
                            new DataColumn("Location", typeof(string)),
                            new DataColumn("Receipt Lines", typeof(string)),
                            new DataColumn("PutAway Lines", typeof(string)),
                            new DataColumn("Movement Lines",typeof(string)),
                            new DataColumn("Picked Lines", typeof(string)),
                            new DataColumn("Packed Packages", typeof(string)),
                            new DataColumn("Shipped Packages", typeof(string))
                            });
            if (objPPD.PickedPerformanceDashboard != null)
            {
                for (int i = 0; i < objPPD.PickedPerformanceDashboard.Count(); i++)
                {

                    if (objPPD.PickedPerformanceDashboard[i].UserID.Contains('\\'))
                    {
                        User = objPPD.PickedPerformanceDashboard[i].UserID.Split('\\');
                        User_ID = User[1];
                    }
                    else
                        User_ID = objPPD.PickedPerformanceDashboard[i].UserID;

                    if (Session["location"] != null && !string.IsNullOrEmpty(txtLocation.Text))
                    {
                        if (txtLocation.Text == objPPD.PickedPerformanceDashboard[i].Location)
                        {
                            dt.Rows.Add(
                        User_ID,
                        objPPD.PickedPerformanceDashboard[i].Location,
                        Convert.ToString(objPPD.PickedPerformanceDashboard[i].NoofReceipt),
                        Convert.ToString(objPPD.PickedPerformanceDashboard[i].NoofPutAway),
                        Convert.ToString(objPPD.PickedPerformanceDashboard[i].NoofMovement),
                        Convert.ToString(objPPD.PickedPerformanceDashboard[i].NoofPicked),
                        Convert.ToString(objPPD.PickedPerformanceDashboard[i].NoofPacked),
                        Convert.ToString(objPPD.PickedPerformanceDashboard[i].NoofShipped)
                        );
                        }
                    }
                    else
                    {
                        dt.Rows.Add(
                        User_ID,
                        objPPD.PickedPerformanceDashboard[i].Location,
                        Convert.ToString(objPPD.PickedPerformanceDashboard[i].NoofReceipt),
                        Convert.ToString(objPPD.PickedPerformanceDashboard[i].NoofPutAway),
                        Convert.ToString(objPPD.PickedPerformanceDashboard[i].NoofMovement),
                        Convert.ToString(objPPD.PickedPerformanceDashboard[i].NoofPicked),
                        Convert.ToString(objPPD.PickedPerformanceDashboard[i].NoofPacked),
                        Convert.ToString(objPPD.PickedPerformanceDashboard[i].NoofShipped)
                        );
                    }
                }
            }

            gvWE.DataSource = dt;
            gvWE.DataBind();

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

    public class WEmployee
    {
        public string UserID { get; set; }
        public string Location { get; set; }
        public int NoofMovement { get; set; }
        public int NoofPacked { get; set; }
        public int NoofPicked { get; set; }
        public int NoofPutAway { get; set; }
        public int NoofReceipt { get; set; }
        public int NoofShipped { get; set; }
    }

    protected void GridView2_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvWE.PageIndex = e.NewPageIndex;
            BindData();
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.alert('" + ex.Message + "');", true);
        }
    }

    protected void Timer1_Tick(object sender, EventArgs e)
    {

        
        if (Session["BatchAnalysis"] as string == "true")
            Response.Redirect("Batch_Analysis.aspx");
        else if (Session["PickCartAnalysis"] as string == "true")
            Response.Redirect("PickCart_Analysis.aspx");
        else if (Session["PickStatus"] as string == "true")
            Response.Redirect("PickStatus.aspx");
        else if (Session["PickedStatus"] as string == "true")
            Response.Redirect("PickedStatus.aspx");
        else if (Session["ShippingStatus"] as string == "true")
            Response.Redirect("OrdersShipping.aspx");
        else if (Session["ShippedStatus"] as string == "true")
            Response.Redirect("OrdersShipped.aspx");
        else if (Session["PickPerformance"] as string == "true")
            Response.Redirect("PickPerformance.aspx");
        else if (Session["PackPerformance"] as string == "true")
            Response.Redirect("PackPerformance.aspx");
        else if (Session["PickedGraph"] as string == "true")
            Response.Redirect("PickedStatusGraph.aspx");
        else if (Session["ShippedGraph"] as string == "true")
            Response.Redirect("ShippedStatusGraph.aspx");
        else if (Session["DailyPick"] as string == "true")
            Response.Redirect("Daily_Picked_Details.aspx");
        else if (Session["DailyShip"] as string == "true")
            Response.Redirect("Daily_Shipped_Details.aspx");
        else if (Session["MonthlyPick"] as string == "true")
            Response.Redirect("Montyly_Picked_Details.aspx");
        else if (Session["MonthlyShip"] as string == "true")
            Response.Redirect("Monthly_Shipped_Details.aspx");
        else if (Session["OrderAnalysis"] as string == "true")
            Response.Redirect("Order_Analysis.aspx");
        else
            Response.Redirect("Employee_Analysis.aspx");

    }

    protected void submit_Click(object sender, EventArgs e)
    {
        Session["location"] = txtLocation.Text;
        Session["date"] = txtdate.Text;
        BindData();
    }
    protected void txtLocation_TextChanged(object sender, EventArgs e)
    {
        Session["location"] = txtLocation.Text;
        BindData();
    }
    protected void txtdate_TextChanged(object sender, EventArgs e)
    {
        Session["date"] = txtdate.Text;
        BindData();
    }
}