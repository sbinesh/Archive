﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WHDB;
using System.Web.Services.Protocols;
using System.Data;
using Highchart.Core.Data.Chart;
using Highchart.Core;
using Highchart.Core.PlotOptions;
using System.Net.Mail;
using System.Net;

public partial class PickedStatus : System.Web.UI.Page
{

    #region Variables

    WarehouseDashboard objservice = new WarehouseDashboard();
    //PickedDetailDashboard PDDRoot = new PickedDetailDashboard();
    //PickedDetailDashboardRoot PDDRoot = new PickedDetailDashboardRoot();
    //PickedHeaderDashboardRoot PDDRoot = new PickedHeaderDashboardRoot();
    PickedHeaderDashboardRoot1 PHDRoot = new PickedHeaderDashboardRoot1();
    //ShippingServiceDashboardRoot SSDRoot = new ShippingServiceDashboardRoot();
    //ShippingServiceDashboard1 SSDRoot = new ShippingServiceDashboard1();

    int statusP = 0;
    private string[,] two_array;
    private bool IsValidate;
    List<Serie> Bar_Series;
    List<Serie> Pie_Series;

    private List<string> Line_Series_Xaxis;
    private List<int> Line_Series_Yaxis;
    private List<object> Pie_obj;
    private object[] Pie_Data;

    List<int> list_str_count = new List<int>();
    int temp_rows_Count = 0;

    string username, password;

    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["Username"] != null && Session["Password"] != null && Session["WHuser"] != null)
            {
                username = Session["Username"].ToString();
                password = Session["Password"].ToString();
            }
            else
            { ScriptManager.RegisterStartupScript(Page, this.GetType(), "myscript", "window.close();", true); return; }

            objservice.Credentials = new System.Net.NetworkCredential(username, password, System.Configuration.ConfigurationManager.AppSettings["Domain"]);

            if (!IsPostBack)
            {
                //ReadService();
                BindData();
            }
        }
        catch (SoapException sx)
        {
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.alert('" + sx.Message + "');", true);
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.alert('" + ex.Message + "');", true);
        }
    }

    protected void Timer1_Tick(object sender, EventArgs e)
    {
       
        if (Session["ShippingStatus"] as string == "true")
            Response.Redirect("OrdersShipping.aspx");
        else if (Session["ShippedStatus"] as string == "true")
            Response.Redirect("OrdersShipped.aspx");
        else if (Session["PickPerformance"] as string == "true")
            Response.Redirect("PickPerformance.aspx");
        else if (Session["PackPerformance"] as string == "true")
            Response.Redirect("PackPerformance.aspx");
        else if (Session["PickedGraph"] as string == "true")
            Response.Redirect("PickedStatusGraph.aspx");
        else if (Session["ShippedGraph"] as string == "true")
            Response.Redirect("ShippedStatusGraph.aspx");
        else if (Session["DailyPick"] as string == "true")
            Response.Redirect("Daily_Picked_Details.aspx");
        else if (Session["DailyShip"] as string == "true")
            Response.Redirect("Daily_Shipped_Details.aspx");
        else if (Session["MonthlyPick"] as string == "true")
            Response.Redirect("Montyly_Picked_Details.aspx");
        else if (Session["MonthlyShip"] as string == "true")
            Response.Redirect("Monthly_Shipped_Details.aspx");
        else if (Session["OrderAnalysis"] as string == "true")
            Response.Redirect("Order_Analysis.aspx");
        else if (Session["EmployeeAnalysis"] as string == "true")
            Response.Redirect("Employee_Analysis.aspx");
        else if (Session["BatchAnalysis"] as string == "true")
            Response.Redirect("Batch_Analysis.aspx");
        else if (Session["PickCartAnalysis"] as string == "true")
            Response.Redirect("PickCart_Analysis.aspx");
        else if (Session["PickStatus"] as string == "true")
            Response.Redirect("PickStatus.aspx");
        else
            Response.Redirect("PickedStatus.aspx");
    }

    protected void txtLocation_TextChanged(object sender, EventArgs e)
    {
        Session["pickedlocation"] = txtLocation.Text;
        Response.Redirect("PickedStatus.aspx");
    }

    private void BindData()
    {
        //PHDRoot = Session["PHDRoot"] as PickedHeaderDashboardRoot;

        //if (PHDRoot == null)
        ReadService();

        if (PHDRoot.PickedHeaderDashboard.Count() > 0)
            for (int i = 0; i < PHDRoot.PickedHeaderDashboard.Length; i++)
            {
                if (string.IsNullOrEmpty(txtLocation.Text))
                {
                    if (PHDRoot.PickedHeaderDashboard[i].Location == System.Configuration.ConfigurationManager.AppSettings["loc1"])
                    {
                        txtLocation.Text = PHDRoot.PickedHeaderDashboard[i].Location;
                        txtdate.Text = PHDRoot.PickedHeaderDashboard[i].Date;
                        txtOrdrPicked.Text = Convert.ToString(PHDRoot.PickedHeaderDashboard[i].OrdersPicked);
                    }
                }
                else if (PHDRoot.PickedHeaderDashboard[i].Location == txtLocation.Text)
                {
                    txtLocation.Text = PHDRoot.PickedHeaderDashboard[i].Location;
                    txtdate.Text = PHDRoot.PickedHeaderDashboard[i].Date;
                    txtOrdrPicked.Text = Convert.ToString(PHDRoot.PickedHeaderDashboard[i].OrdersPicked);
                }

            }

        Array.Sort(PHDRoot.PickedHeaderDashboard[0].ShippingServiceDashboard, delegate(ShippingServiceDashboard2 s1, ShippingServiceDashboard2 s2)
        {
            return s1.Priority.CompareTo(s2.Priority);
        });


        Line_Series_Xaxis = new List<string>();
        Line_Series_Yaxis = new List<int>();

        DataTable dt = new DataTable();
        for (int i = 0; i < PHDRoot.PickedHeaderDashboard.Length; i++)
        {
            for (int j = 0; j < PHDRoot.PickedHeaderDashboard[i].ShippingServiceDashboard.Length; j++)
            {
                AddColumn(dt, i, j);
            }
        }

        var SDD_Count = 0;



        for (int i = 0; i < PHDRoot.PickedHeaderDashboard.Length; i++)
            for (int j = 0; j < PHDRoot.PickedHeaderDashboard[i].PickedDetailDashboard.Length; j++)
                SDD_Count++;

        two_array = new string[1, SDD_Count];
        var SDD_Count_Array = 0;


        for (int i = 0; i < PHDRoot.PickedHeaderDashboard.Length; i++)
        {
            for (int j = 0; j < PHDRoot.PickedHeaderDashboard[i].PickedDetailDashboard.Length; j++)
            {
                if (string.IsNullOrEmpty(txtLocation.Text))
                {
                    if (PHDRoot.PickedHeaderDashboard[i].Location == System.Configuration.ConfigurationManager.AppSettings["loc1"])
                    {
                        string[] HU;
                        string HUser = "";

                        if (PHDRoot.PickedHeaderDashboard[i].PickedDetailDashboard[j].HandledUser.Contains("\\"))
                        {
                            HU = PHDRoot.PickedHeaderDashboard[i].PickedDetailDashboard[j].HandledUser.Split('\\');
                            HUser = HU[1];
                        }
                        else
                            HUser = PHDRoot.PickedHeaderDashboard[i].PickedDetailDashboard[j].HandledUser;




                        two_array[0, SDD_Count_Array] = PHDRoot.PickedHeaderDashboard[i].PickedDetailDashboard[j].ShippingAgent
                                        + "," + PHDRoot.PickedHeaderDashboard[i].PickedDetailDashboard[j].ShippingAgentService
                                        + "," + PHDRoot.PickedHeaderDashboard[i].PickedDetailDashboard[j].Type
                                        + "," + PHDRoot.PickedHeaderDashboard[i].PickedDetailDashboard[j].OrderNo
                                        + "," + HUser
                                        + ",";
                        SDD_Count_Array++;
                        HU = null; HUser = null;

                    }
                }
                else if (PHDRoot.PickedHeaderDashboard[i].Location == txtLocation.Text)
                {
                    string[] HU;
                    string HUser = "";

                    if (PHDRoot.PickedHeaderDashboard[i].PickedDetailDashboard[j].HandledUser.Contains("\\"))
                    {
                        HU = PHDRoot.PickedHeaderDashboard[i].PickedDetailDashboard[j].HandledUser.Split('\\');
                        HUser = HU[1];
                    }
                    else
                        HUser = PHDRoot.PickedHeaderDashboard[i].PickedDetailDashboard[j].HandledUser;




                    two_array[0, SDD_Count_Array] = PHDRoot.PickedHeaderDashboard[i].PickedDetailDashboard[j].ShippingAgent
                                    + "," + PHDRoot.PickedHeaderDashboard[i].PickedDetailDashboard[j].ShippingAgentService
                                    + "," + PHDRoot.PickedHeaderDashboard[i].PickedDetailDashboard[j].Type
                                    + "," + PHDRoot.PickedHeaderDashboard[i].PickedDetailDashboard[j].OrderNo
                                    + "," + HUser
                                    + ",";
                    SDD_Count_Array++;
                    HU = null; HUser = null;
                }

            }

        }

        int jtemp = 0;
        int itemp = 0;
        int temp_num_ords_Count = 0;

        for (int i = 0; i < dt.Columns.Count; i++)
        {
            int temp = 0; temp_num_ords_Count = 0; temp_rows_Count = 0;

            for (int j = 0; j < two_array.GetLength(0); j++)
            {
                jtemp = 0;
                if (two_array[j, i] != null)
                {
                    for (int k = 0; k < two_array.Length; k++)
                    {
                        if (two_array[itemp, jtemp] != null)
                        {
                            string[] Value = two_array[itemp, jtemp].Split(',');

                            string Shp_Agnt_Srvc = Value[0] + (Value[1] != string.Empty ? " - " + Value[1] : "");

                            if (Shp_Agnt_Srvc.ToString() == "FEDEX - FEDEX")
                                Shp_Agnt_Srvc = "FEDEX";
                            else if (Shp_Agnt_Srvc.ToString() == "CUSTPICKUP - CUST. PICKUP")
                                Shp_Agnt_Srvc = "CUST. PICKUP";
                            else if (Shp_Agnt_Srvc.ToString() == "OWN LOG. - STANDARD")
                                Shp_Agnt_Srvc = "OWN LOG.";
                            else if (Shp_Agnt_Srvc.ToString() == "USPS - USPS")
                                Shp_Agnt_Srvc = "USPS";

                            if (Shp_Agnt_Srvc == dt.Columns[i].ColumnName)
                            {
                                if (!string.IsNullOrWhiteSpace(two_array[j, i].ToString()))
                                {
                                    dt.Rows.Add();
                                    dt.Rows[temp][dt.Columns[i].ColumnName] = Value[3] + (Value[4] != string.Empty ? " - " + Value[4] : "")
                                        + (Value[5] != string.Empty ? " - " + Value[5] : "");
                                    temp++;
                                    temp_num_ords_Count++;
                                    temp_rows_Count++;
                                }
                            }
                            jtemp++;
                        }
                    }
                }
            }
            Line_Series_Yaxis.Add(temp_num_ords_Count);
            list_str_count.Add(temp_rows_Count);
        }

        if (!IsValidate)
            if (Line_Series_Xaxis.Count != 0)
            {

                #region Bar Chart

                string[] str_obj = Line_Series_Xaxis.ToArray();
                int[] inr = Line_Series_Yaxis.ToArray();

                object[] obj = Array.ConvertAll(inr, x => (object)x);

                Bar_Series = new List<Serie>();

                BarChart1.YAxis.Clear();
                BarChart1.XAxis.Clear();

                DataLabels dl = new DataLabels();
                dl.enabled = true;
                dl.color = "red";
                dl.x = 2;
                dl.y = 10;

                dl.style = new Highchart.Core.Appearance.CSSObject();
                dl.style.font = "Arial Black";
                dl.style.fontSize = "20px";
                dl.style.fontWeight = "900";

                BarChart1.PlotOptions = new PlotOptionsBar { dataLabels = dl, showInLegend = false };

                BarChart1.Colors = new Highchart.Core.Appearance.ColorSet();
                BarChart1.Colors.colors = new string[] { "Green" };

                BarChart1.Appearance = new Highchart.Core.Appearance.Appearance();
                BarChart1.Appearance.borderColor = "#E34335";
                //BarChart1.Appearance.borderRadius = 15;
                BarChart1.Appearance.borderWidth = 1;

                Labels lbl = new Labels();
                //lbl.style = new Highchart.Core.Appearance.CSSObject();
                //lbl.style.color = "Green";

                BarChart1.YAxis.Add(new YAxisItem { title = new Title("Number of Orders") });
                BarChart1.XAxis.Add(new XAxisItem { categories = str_obj, labels = lbl });
                Bar_Series.Add(new Serie { data = obj });

                if (BarChart1.XAxis.Count == 1 && BarChart1.YAxis.Count == 1)
                {
                    //BarChart1.XAxis[0].title = new Highchart.Core.Title("Candy Warehouse - Order Pick Status");
                    BarChart1.XAxis[0].title = new Highchart.Core.Title("Carrier Options");
                    BarChart1.XAxis[0].title.style = new Highchart.Core.Appearance.CSSObject();
                    BarChart1.XAxis[0].title.style.color = "#0367B0";
                    BarChart1.XAxis[0].title.style.font = "Arial Black";
                    BarChart1.XAxis[0].title.style.fontSize = "25px";
                    BarChart1.XAxis[0].title.style.fontWeight = "900";
                    /* Services Styles */
                    BarChart1.XAxis[0].labels.style = new Highchart.Core.Appearance.CSSObject();
                    BarChart1.XAxis[0].labels.style.fontSize = "15px";
                    BarChart1.XAxis[0].labels.style.font = "Arial Black";
                    BarChart1.XAxis[0].labels.style.color = "magenta";
                    BarChart1.XAxis[0].labels.x = -2;
                    BarChart1.XAxis[0].labels.y = 7;
                    //BarChart1.XAxis[0].gridLineColor = "White";
                    //BarChart1.XAxis[0].alternateGridColor = "White";
                    //BarChart1.XAxis[0].gridLineDashStyle = DashStyle.Solid;
                    //BarChart1.XAxis[0].minorGridLineColor = "white";
                    //BarChart1.XAxis[0].showFirstLabel = false;
                    //BarChart1.XAxis[0].showLastLabel = false;

                    BarChart1.YAxis[0].title = new Highchart.Core.Title("Number of Orders");
                    BarChart1.YAxis[0].title.style = new Highchart.Core.Appearance.CSSObject();
                    BarChart1.YAxis[0].title.style.color = "#0367B0";
                    BarChart1.YAxis[0].title.style.font = "Aria Black";
                    BarChart1.YAxis[0].title.style.fontSize = "25px";
                    BarChart1.YAxis[0].title.style.fontWeight = "900";
                }

                BarChart1.DataSource = null;

                BarChart1.ShowCredits = false;

                BarChart1.DataSource = Bar_Series;
                BarChart1.DataBind();

                #endregion
                //S
                #region Pie chart

                PieChart1.Title = new Title("Carrier Options");
                PieChart1.Title.style = new Highchart.Core.Appearance.CSSObject();
                PieChart1.Title.style.color = "#0367B0";
                PieChart1.Title.style.font = "Aria Black";
                PieChart1.Title.style.fontSize = "25";
                PieChart1.Title.style.fontWeight = "900";
                PieChart1.Appearance = new Highchart.Core.Appearance.Appearance();
                PieChart1.Appearance.borderColor = "#E34335";
                PieChart1.Appearance.borderWidth = 1;

                Pie_obj = new List<object>();
                for (int i = 0; i < Line_Series_Xaxis.Count; i++)
                {
                    Pie_Data = new object[] { 
                Line_Series_Xaxis[i],
                Line_Series_Yaxis[i]
            };

                    Pie_obj.Add(Pie_Data);
                }
                var P = Pie_obj.ToArray();
                Pie_Series = new List<Serie>();
                Pie_Series.Add(new Serie
                {
                    size = 130,
                    data = P,
                });

                var objstyle = new Highchart.Core.Appearance.CSSObject();
                objstyle.font = "Arial Black";
                objstyle.fontSize = "20";
                objstyle.fontWeight = "900";

                PieChart1.PlotOptions = new PlotOptionsPie
                {
                    allowPointSelect = true,
                    cursor = "pointer",
                    showInLegend = true,
                    dataLabels = new DataLabels { enabled = true, formatter = "this.y", style = objstyle },
                };

                PieChart1.Colors = new Highchart.Core.Appearance.ColorSet();
                //PieChart1.Colors.colors = new string[] { "red", "green", "blue", "yellow", "black", "chocolate", "Aqua", "BlueViolet", "Fuchsia", "LightSeaGreen", "MidnightBlue", "Olive", "DarkMagenta" };
                PieChart1.Colors.colors = new string[] { "#00FFFF", "#DAA520", "#0000FF", "#8A2BE2", "#A52A2A", "#008B8B", "#7FFF00", "#D2691E", "#6495ED", "#00008B", "#8B008B", "#2F4F4F", "green" };

                PieChart1.Tooltip = new ToolTip("'<b>'+ this.point.name +'</b>: '+ this.y +' '");
                PieChart1.Theme = "skies";
                //PieChart1.Theme = "gray-floral";

                PieChart1.DataSource = Pie_Series;
                PieChart1.DataBind();

                #endregion
            }


        //gvPickedSatus.DataBound += new EventHandler(gvOPicked_DataBound);

        RemoveNullColumnFromDataTable(dt);
        gvPickedSatus.DataSource = dt;
        gvPickedSatus.DataBind();


    }

    private void AddColumn(DataTable dt, int i, int j)
    {
        try
        {
            var Service_Name = PHDRoot.PickedHeaderDashboard[i].ShippingServiceDashboard[j].ShippingAgent
       + (PHDRoot.PickedHeaderDashboard[i].ShippingServiceDashboard[j].ShippingAgentService != string.Empty ? " - "
       + PHDRoot.PickedHeaderDashboard[i].ShippingServiceDashboard[j].ShippingAgentService : "");

            DataColumnCollection columns = dt.Columns;

            if (Session["pickedlocation"] != null)
                txtLocation.Text = Session["pickedlocation"].ToString();

            if (!string.IsNullOrEmpty(Service_Name))
            {
                string[] str = Service_Name.Split('-');
                if (!columns.Contains(Service_Name) && !columns.Contains(str[1].TrimStart(' ')))
                {
                    if (string.IsNullOrEmpty(txtLocation.Text))
                    {
                        if (PHDRoot.PickedHeaderDashboard[i].Location == System.Configuration.ConfigurationManager.AppSettings["loc1"])
                        {
                            DataColumn dcol = new DataColumn(Service_Name);
                            if (dcol.ToString() == "FEDEX - FEDEX")
                                dt.Columns.Add("FEDEX");
                            else if (dcol.ToString() == "CUSTPICKUP - CUST. PICKUP")
                                dt.Columns.Add("CUST. PICKUP");
                            else if (dcol.ToString() == "OWN LOG. - STANDARD")
                                dt.Columns.Add("OWN LOG.");
                            else if (dcol.ToString() == "USPS - USPS")
                                dt.Columns.Add("USPS");
                            else
                                dt.Columns.Add(dcol);
                            //Line_Series_Xaxis.Add(Service_Name);


                            if (Service_Name == "FEDEX - FEDEX")
                                Line_Series_Xaxis.Add("FEDEX");
                            else if (Service_Name == "CUSTPICKUP - CUST. PICKUP")
                                Line_Series_Xaxis.Add("CUST. PICKUP");
                            else if (Service_Name == "OWN LOG. - STANDARD")
                                Line_Series_Xaxis.Add("OWN LOG.");
                            else if (Service_Name == "USPS - USPS")
                                Line_Series_Xaxis.Add("USPS");
                            else
                                Line_Series_Xaxis.Add(Service_Name);
                        }
                    }
                    else if (PHDRoot.PickedHeaderDashboard[i].Location == txtLocation.Text)
                    {
                        DataColumn dcol = new DataColumn(Service_Name);
                        if (dcol.ToString() == "FEDEX - FEDEX")
                            dt.Columns.Add("FEDEX");
                        else if (dcol.ToString() == "CUSTPICKUP - CUST. PICKUP")
                            dt.Columns.Add("CUST. PICKUP");
                        else if (dcol.ToString() == "OWN LOG. - STANDARD")
                            dt.Columns.Add("OWN LOG.");
                        else if (dcol.ToString() == "USPS - USPS")
                            dt.Columns.Add("USPS");
                        else
                            dt.Columns.Add(dcol);
                        //Line_Series_Xaxis.Add(Service_Name);


                        if (Service_Name == "FEDEX - FEDEX")
                            Line_Series_Xaxis.Add("FEDEX");
                        else if (Service_Name == "CUSTPICKUP - CUST. PICKUP")
                            Line_Series_Xaxis.Add("CUST. PICKUP");
                        else if (Service_Name == "OWN LOG. - STANDARD")
                            Line_Series_Xaxis.Add("OWN LOG.");
                        else if (Service_Name == "USPS - USPS")
                            Line_Series_Xaxis.Add("USPS");
                        else
                            Line_Series_Xaxis.Add(Service_Name);
                    }
                }
            }

        }
        catch (Exception ex)
        {

        }


    }

    public void RemoveNullColumnFromDataTable(DataTable dt)
    {
        int indexMax = !list_str_count.Any() ? -1 :
               list_str_count.Select((value, index) => new { Value = value, Index = index }).Aggregate((a, b) => (a.Value > b.Value) ? a : b).Index;
        for (int i = dt.Rows.Count - 1; i >= 0; i--)
        {
            if (dt.Rows[i][indexMax] == DBNull.Value)
                dt.Rows[i].Delete();
        }
        dt.AcceptChanges();
    }

    private void ReadService()
    {
        string date = System.DateTime.Now.ToString("MM/dd/yy");
        //date = "10/01/2015";
        //objservice.PickedDashboard(date, ref PHDRoot, ref SSDRoot, ref PDDRoot, ref statusP);
        //objservice.PickedDashboard(date, ref PHDRoot, ref statusP);
        objservice.DailyPickedDashboard(date, ref PHDRoot, ref statusP);
        //Session["PHDRoot"] = PHDRoot;
        //Session["SSDRoot"] = PHDRoot.PickedHeaderDashboard[0].ShippingServiceDashboard;
        //Session["PDDRoot"] = PHDRoot.PickedHeaderDashboard[0].PickedDetailDashboard;
    }

    protected void gvPickedSatus_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            IsValidate = true;
            gvPickedSatus.PageIndex = e.NewPageIndex;
            Pie_Series = null;
            Bar_Series = null;
            BindData();
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.alert('" + ex.Message + "');", true);
        }
    }

    protected void tmrRefreshChart_Tick(object sender, EventArgs e)
    {
        try
        {
            //ReadService();
            //BindTabData();
            //BindGridViewData();
        }
        catch (SoapException sx)
        {
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.alert('" + sx.Message + "');", true);
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.alert('" + ex.Message + "');", true);
        }

    }

    private void SendMail(string targetMail, string shownTargetName, string[] attachmentNames, string Username, string Password, string subject, string body)
    {
        var fromAddress = new MailAddress("support@gmail.com", "MailSendingPrag");
        var toAddress = new MailAddress(targetMail, shownTargetName);
        const string fromPassword = "12345isAbadPassword";
        subject = "Your Subject";
        body = @"Here you can put in" + Username + "and" + Password + "that will appear in the body          multilined and even in <html>        ";
        var smtp = new SmtpClient
        {
            Host = "smtp.google.com",
            Port = 587,
            EnableSsl = true,
            DeliveryMethod = SmtpDeliveryMethod.Network,
            UseDefaultCredentials = false,
            Credentials = new NetworkCredential(fromAddress.Address, fromPassword)
        };

        using (var message = new MailMessage(fromAddress, toAddress)
        {
            Subject = subject,
            Body = body
        }
              )
        {
            foreach (string filePath in attachmentNames)
            {
                Attachment attachMail = new Attachment(filePath);
                message.Attachments.Add(attachMail);
            }

            try
            {
                smtp.Send(message);
                Response.Write("E-Mail sent!");
            }
            catch
            {
                Response.Write("Sending failed, check your internet connection!");
            }
        }
    }


}