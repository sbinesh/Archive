﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Mainmenu : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Username"] == null && Session["Password"] == null && Session["WHuser"] == null)
        { ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.top.navigate('../LogIn.aspx');", true); return; }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        Page.ClientScript.RegisterStartupScript(this.GetType(), "OpenWindow", @"window.open('\PickStatus.aspx','_newtab');", true);
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Write("<script>window.open('PickedStatus.aspx');</script>");
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        Response.Write("<script>window.open('OrdersShipping.aspx');</script>");
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Write("<script>window.open('OrdersShipped.aspx');</script>");
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        //Session["SlideShow"] = "true";
        Response.Write("<script>window.open('SlideShow_Select.aspx');</script>");
    }

    protected void Button7_Click(object sender, EventArgs e)
    {
        Response.Write("<script>window.open('PickedStatusGraph.aspx');</script>");
    }
    protected void Button8_Click(object sender, EventArgs e)
    {
        Response.Write("<script>window.open('ShippedStatusGraph.aspx');</script>");
    }
    protected void Button9_Click(object sender, EventArgs e)
    {
        Response.Write("<script>window.open('PickPerformance.aspx');</script>");
    }
    protected void Button10_Click(object sender, EventArgs e)
    {
        Response.Write("<script>window.open('PackPerformance.aspx');</script>");
    }

    protected void btnDailyPSG_Click(object sender, EventArgs e)
    {
        Response.Write("<script>window.open('Daily_Picked_Details.aspx');</script>");
    }

    protected void Button11_Click(object sender, EventArgs e)
    {
        Response.Write("<script>window.open('Daily_Shipped_Details.aspx');</script>");
    }
    protected void Button12_Click(object sender, EventArgs e)
    {
        Response.Write("<script>window.open('Montyly_Picked_Details.aspx');</script>");
    }
    protected void Button13_Click(object sender, EventArgs e)
    {
        Response.Write("<script>window.open('Monthly_Shipped_Details.aspx');</script>");
    }

    protected void EmployeeAnalysis(object sender, EventArgs e)
    {
        Response.Write("<script>window.open('Employee_Analysis.aspx');</script>");
    }
    protected void WHAnalysis(object sender, EventArgs e)
    {
        Response.Write("<script>window.open('Order_Analysis.aspx');</script>");
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        Response.Write("<script>window.open('Batch_Analysis.aspx');</script>");
    }
    protected void Button14_Click(object sender, EventArgs e)
    {
        Response.Write("<script>window.open('PickCart_Analysis.aspx');</script>");
    }


}
