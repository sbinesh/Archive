﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WHDB;

public partial class ShippedStatusGraph : System.Web.UI.Page
{
    WarehouseDashboard objservice = new WarehouseDashboard();
    ShippedHeaderDashboardRoot SHDRoot = new ShippedHeaderDashboardRoot();
    private string username;
    private string password;
    int statusP = 0;

    List<string> Dates = new List<string>();
    List<int> TotalOrderCount = new List<int>();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Username"] == null && Session["Password"] == null && Session["WHuser"] == null)
        {
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "myscript", "window.close();", true); return;
        }

        username = Session["Username"].ToString();
        password = Session["Password"].ToString();

        objservice.Credentials = new System.Net.NetworkCredential(username, password, System.Configuration.ConfigurationManager.AppSettings["Domain"]);

        if (!IsPostBack)
            BindData();
    }

    private void BindData()
    {
        try
        {
            DateTime firstDay = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
            DateTime lastDay = firstDay.AddMonths(1).AddDays(-1);

            string date = firstDay.ToString("MM/dd/yy") + ".." + lastDay.ToString("MM/dd/yy");

            objservice.MonthlyShippedDashboard(date, ref SHDRoot, ref statusP);

            List<string> str_obj = new List<string>();

            for (int i = 0; i < SHDRoot.ShippedHeaderDashboard.Length; i++)
            {
                if (SHDRoot.ShippedHeaderDashboard[i].Location == (string.IsNullOrEmpty(txtLocation.Text) ? System.Configuration.ConfigurationManager.AppSettings["loc1"] : txtLocation.Text))
                {
                    Dates.Add(SHDRoot.ShippedHeaderDashboard[i].Date);
                    TotalOrderCount.Add(SHDRoot.ShippedHeaderDashboard[i].OrdersShipped);
                    for (int j = 0; j < SHDRoot.ShippedHeaderDashboard[i].ShippingServiceDashboard.Length; j++)
                    {
                        string str2 = SHDRoot.ShippedHeaderDashboard[i].ShippingServiceDashboard[j].ShippingAgent + "-" + SHDRoot.ShippedHeaderDashboard[i].ShippingServiceDashboard[j].ShippingAgentService;
                        if (!str_obj.Contains(str2))
                            str_obj.Add(str2);
                    }
                }
            }

            object[][] str = new object[str_obj.Count][];

            for (int i = 0; i < str_obj.Count; i++)
            {
                str[i] = new object[Dates.Count];
                for (int p = 0; p < Dates.Count; p++)
                {
                    for (int j = 0; j < SHDRoot.ShippedHeaderDashboard.Length; j++)
                    {
                        if (SHDRoot.ShippedHeaderDashboard[j].Location == (string.IsNullOrEmpty(txtLocation.Text) ? System.Configuration.ConfigurationManager.AppSettings["loc1"] : txtLocation.Text))
                        {
                            for (int k = 0; k < SHDRoot.ShippedHeaderDashboard[j].ShippingServiceDashboard.Length; k++)
                            {
                                string srvc = SHDRoot.ShippedHeaderDashboard[j].ShippingServiceDashboard[k].ShippingAgent + "-" + SHDRoot.ShippedHeaderDashboard[j].ShippingServiceDashboard[k].ShippingAgentService;
                                if (Dates[p] == SHDRoot.ShippedHeaderDashboard[j].Date && (srvc == str_obj[i]))
                                {
                                    str[i][p] = SHDRoot.ShippedHeaderDashboard[j].ShippingServiceDashboard[k].NoofOrders;
                                }
                            }
                        }
                    }
                }
            }

            DotNet.Highcharts.Options.Series[] s = new DotNet.Highcharts.Options.Series[str_obj.Count + 1];

            for (int i = 0; i < str_obj.Count; i++)
            {
                s[i] = new DotNet.Highcharts.Options.Series();
                s[i].Data = new DotNet.Highcharts.Helpers.Data(str[i]);
                s[i].Type = DotNet.Highcharts.Enums.ChartTypes.Column;
                s[i].Name = str_obj[i];
            }

            s[str_obj.Count] = new DotNet.Highcharts.Options.Series();
            s[str_obj.Count].Data = new DotNet.Highcharts.Helpers.Data(TotalOrderCount.Cast<object>().ToArray());
            s[str_obj.Count].Type = DotNet.Highcharts.Enums.ChartTypes.Line;
            s[str_obj.Count].Name = "Total Orders";


            DotNet.Highcharts.Highcharts chart = new DotNet.Highcharts.Highcharts("chart").SetXAxis(new DotNet.Highcharts.Options.XAxis { Categories = Dates.ToArray(), Labels = new DotNet.Highcharts.Options.XAxisLabels { Rotation = 300, Format = "<b>{value}</b>", Y = 35, Style = @"color: '#0033CC', fontSize: '14px',fontWeight: '900',fontFamily: 'Arial Black'" } })
            .SetSeries(s);

            chart.SetTitle(new DotNet.Highcharts.Options.Title { Style = @"fontSize: '30px', fontWeight: '900', fontFamily: 'Arial Black'", Margin = 100, Text = @"<b>ORDER\'S SHIPPED <br/>" + System.DateTime.Now.ToString("MMMM", System.Globalization.CultureInfo.InvariantCulture).ToUpper() + " " + System.DateTime.Now.Year + "</b>" });

            DotNet.Highcharts.Options.Credits cr = new DotNet.Highcharts.Options.Credits();
            cr.Enabled = false;
            chart.SetCredits(cr);


            DotNet.Highcharts.Options.Legend legend = new DotNet.Highcharts.Options.Legend();
            legend.ItemStyle = @"fontSize: '25px',fontWeight: '900'";

            chart.SetLegend(legend);

            DotNet.Highcharts.Options.PlotOptions PO = new DotNet.Highcharts.Options.PlotOptions();
            PO.Column = new DotNet.Highcharts.Options.PlotOptionsColumn();
            PO.Column.Cursor = DotNet.Highcharts.Enums.Cursors.Pointer;
            PO.Column.DataLabels = new DotNet.Highcharts.Options.PlotOptionsColumnDataLabels();
            PO.Column.DataLabels.Enabled = true;
            PO.Column.DataLabels.Rotation = 270;
            PO.Column.DataLabels.Format = "<b>{y}</b>";
            PO.Column.DataLabels.X = 5;
            PO.Column.DataLabels.Y = -15;
            PO.Column.DataLabels.Color = System.Drawing.Color.Red;

            PO.Line = new DotNet.Highcharts.Options.PlotOptionsLine();
            PO.Line.Cursor = DotNet.Highcharts.Enums.Cursors.Pointer;
            PO.Line.DataLabels = new DotNet.Highcharts.Options.PlotOptionsLineDataLabels();
            PO.Line.DataLabels.Enabled = true;
            PO.Line.DataLabels.Format = "<b>{y}</b>";
            PO.Line.DataLabels.Color = System.Drawing.Color.Red;
            PO.Line.Color = System.Drawing.Color.Green;

            chart.SetPlotOptions(PO);

            DotNet.Highcharts.Options.YAxisTitle yaxis = new DotNet.Highcharts.Options.YAxisTitle();
            yaxis.Text = "No. of Orders";
            yaxis.Style = @"fontSize : '25px', fontWeight: '900', fontFamily: 'Arial Black'";

            chart.SetYAxis(new DotNet.Highcharts.Options.YAxis { Title = yaxis, Labels = new DotNet.Highcharts.Options.YAxisLabels { Y = 5, Format = "<b>{value}</b>", Style = @"color: '#0033CC', fontSize: '14px', fontWeight: '900', fontFamily: 'Arial Black'" } });

            ltrChart.Text = chart.ToHtmlString();

        }
        catch (Exception ex)
        {
            string msg = ex.Message.Replace("'", "");
            msg = msg.Replace("\n", "");
            //msg = msg + "\n";
            //lblErrorMsg.Text = msg;
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.alert('" + msg + "');", true);
        }
    }

    protected void Timer1_Tick(object sender, EventArgs e)
    {
        
        if (Session["DailyPick"] as string == "true")
            Response.Redirect("Daily_Picked_Details.aspx");
        else if (Session["DailyShip"] as string == "true")
            Response.Redirect("Daily_Shipped_Details.aspx");
        else if (Session["MonthlyPick"] as string == "true")
            Response.Redirect("Montyly_Picked_Details.aspx");
        else if (Session["MonthlyShip"] as string == "true")
            Response.Redirect("Monthly_Shipped_Details.aspx");
        else if (Session["OrderAnalysis"] as string == "true")
            Response.Redirect("Order_Analysis.aspx");
        else if (Session["EmployeeAnalysis"] as string == "true")
            Response.Redirect("Employee_Analysis.aspx");
        else if (Session["BatchAnalysis"] as string == "true")
            Response.Redirect("Batch_Analysis.aspx");
        else if (Session["PickCartAnalysis"] as string == "true")
            Response.Redirect("PickCart_Analysis.aspx");
        else if (Session["PickStatus"] as string == "true")
            Response.Redirect("PickStatus.aspx");
        else if (Session["PickedStatus"] as string == "true")
            Response.Redirect("PickedStatus.aspx");
        else if (Session["ShippingStatus"] as string == "true")
            Response.Redirect("OrdersShipping.aspx");
        else if (Session["ShippedStatus"] as string == "true")
            Response.Redirect("OrdersShipped.aspx");
        else if (Session["PickPerformance"] as string == "true")
            Response.Redirect("PickPerformance.aspx");
        else if (Session["PackPerformance"] as string == "true")
            Response.Redirect("PackPerformance.aspx");
        else if (Session["PickedGraph"] as string == "true")
            Response.Redirect("PickedStatusGraph.aspx");
        else
            Response.Redirect("ShippedStatusGraph.aspx");

    }

    protected void txtlocation_TextChanged(object sender, EventArgs e)
    {
        BindData();
    }
}