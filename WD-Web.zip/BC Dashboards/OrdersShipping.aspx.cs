﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using WHDB;
using Highchart.Core.Data.Chart;
using System.Web.Services.Protocols;
using System.Data;
using Highchart.Core;
using Highchart.Core.PlotOptions;

public partial class OrdersShipping : System.Web.UI.Page
{
    #region Variables

    WarehouseDashboard objservice = new WarehouseDashboard();
    ShippingServiceDashboardRoot pickshp_root = new ShippingServiceDashboardRoot();
    ShipHeaderDashboardRoot ShipHeader = new ShipHeaderDashboardRoot();
    ShipDetailDashboardRoot ShipDetail = new ShipDetailDashboardRoot();
    int status = 0;
    private string[,] two_array;
    private bool IsValideate;
    List<Serie> Bar_Series;
    List<Serie> Pie_Series;
    private List<string> Line_Series_Xaxis;
    private List<int> Line_Series_Yaxis;
    private List<object> Pie_obj;
    private object[] Pie_Data;

    List<int> list_str_count = new List<int>();
    int temp_rows_Count = 0;

    string username, password;

    #endregion

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (Session["Username"] != null && Session["Password"] != null && Session["WHuser"] != null)
            {
                username = Session["Username"].ToString();
                password = Session["Password"].ToString();
            }
            else
            { ScriptManager.RegisterStartupScript(Page, this.GetType(), "myscript", "window.close();", true); return; }

            objservice.Credentials = new System.Net.NetworkCredential(username, password, System.Configuration.ConfigurationManager.AppSettings["Domain"]);
            if (!IsPostBack)
            {
                //GetBindData();
                GetDashboard_GridDetails();
                GetDashboardDetails();
            }
        }
        catch (SoapException sx)
        {
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.alert('" + sx.Message + "');", true);
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.alert('" + ex.Message + "');", true);
        }
    }

    protected void Timer1_Tick(object sender, EventArgs e)
    {
       if (Session["ShippedStatus"] as string == "true")
            Response.Redirect("OrdersShipped.aspx");
        else if (Session["PickPerformance"] as string == "true")
            Response.Redirect("PickPerformance.aspx");
        else if (Session["PackPerformance"] as string == "true")
            Response.Redirect("PackPerformance.aspx");
        else if (Session["PickedGraph"] as string == "true")
            Response.Redirect("PickedStatusGraph.aspx");
        else if (Session["ShippedGraph"] as string == "true")
            Response.Redirect("ShippedStatusGraph.aspx");
        else if (Session["DailyPick"] as string == "true")
            Response.Redirect("Daily_Picked_Details.aspx");
        else if (Session["DailyShip"] as string == "true")
            Response.Redirect("Daily_Shipped_Details.aspx");
        else if (Session["MonthlyPick"] as string == "true")
            Response.Redirect("Montyly_Picked_Details.aspx");
        else if (Session["MonthlyShip"] as string == "true")
            Response.Redirect("Monthly_Shipped_Details.aspx");
        else if (Session["OrderAnalysis"] as string == "true")
            Response.Redirect("Order_Analysis.aspx");
        else if (Session["EmployeeAnalysis"] as string == "true")
            Response.Redirect("Employee_Analysis.aspx");
       else if (Session["BatchAnalysis"] as string == "true")
           Response.Redirect("Batch_Analysis.aspx");
       else if (Session["PickCartAnalysis"] as string == "true")
           Response.Redirect("PickCart_Analysis.aspx");
        else if (Session["PickStatus"] as string == "true")
            Response.Redirect("PickStatus.aspx");
        else if (Session["PickedStatus"] as string == "true")
            Response.Redirect("PickedStatus.aspx");
        else
            Response.Redirect("OrdersShipping.aspx");

    }

    private void GetDashboard_GridDetails()
    {
        //ShipHeader = Session["ShipHeaderDash"] as ShipHeaderDashboardRoot;
        //pickshp_root = Session["ShpSrvcDash"] as ShippingServiceDashboardRoot;
        //ShipDetail = Session["ShipDetailsDash"] as ShipDetailDashboardRoot;
        //
        //if (ShipHeader.ShipHeaderDashboard == null || pickshp_root.ShippingServiceDashboard == null || ShipDetail.ShipDetailDashboard == null)
        GetBindData();

        Array.Sort(pickshp_root.ShippingServiceDashboard, delegate(ShippingServiceDashboard1 s1, ShippingServiceDashboard1 s2)
        {
            return s1.Priority.CompareTo(s2.Priority);
        });

        Line_Series_Xaxis = new List<string>();
        Line_Series_Yaxis = new List<int>();

        DataTable dt = new DataTable();
        int counter = 0;
        if (Session["shippinglocation"] != null)
            txtLocation.Text = Session["shippinglocation"].ToString();

        for (int i = 0; i < pickshp_root.ShippingServiceDashboard.Length; i++)
        {
            if (string.IsNullOrEmpty(txtLocation.Text))
            {
                if (pickshp_root.ShippingServiceDashboard[i].LocationCode == System.Configuration.ConfigurationManager.AppSettings["loc1"])
                {
                    var colName = pickshp_root.ShippingServiceDashboard[i].ShippingAgent + (pickshp_root.ShippingServiceDashboard[i].ShippingAgentService != string.Empty ? " - " + pickshp_root.ShippingServiceDashboard[i].ShippingAgentService : "");
                    DataColumn dcol = new DataColumn(colName);
                    if (dcol.ToString() == "FEDEX - FEDEX")
                        dt.Columns.Add("FEDEX");
                    else if (dcol.ToString() == "CUSTPICKUP - CUST. PICKUP")
                        dt.Columns.Add("CUST. PICKUP");
                    else if (dcol.ToString() == "OWN LOG. - STANDARD")
                        dt.Columns.Add("OWN LOG.");
                    else if (dcol.ToString() == "USPS - USPS")
                        dt.Columns.Add("USPS");
                    else
                        dt.Columns.Add(dcol);

                    Line_Series_Xaxis.Add(dt.Columns[counter].ColumnName);
                    counter++;
                }
            }
            else if (pickshp_root.ShippingServiceDashboard[i].LocationCode == txtLocation.Text)
            {
                var colName = pickshp_root.ShippingServiceDashboard[i].ShippingAgent + (pickshp_root.ShippingServiceDashboard[i].ShippingAgentService != string.Empty ? " - " + pickshp_root.ShippingServiceDashboard[i].ShippingAgentService : "");
                DataColumn dcol = new DataColumn(colName);
                if (dcol.ToString() == "FEDEX - FEDEX")
                    dt.Columns.Add("FEDEX");
                else if (dcol.ToString() == "CUSTPICKUP - CUST. PICKUP")
                    dt.Columns.Add("CUST. PICKUP");
                else if (dcol.ToString() == "OWN LOG. - STANDARD")
                    dt.Columns.Add("OWN LOG.");
                else if (dcol.ToString() == "USPS - USPS")
                    dt.Columns.Add("USPS");
                else
                    dt.Columns.Add(dcol);

                Line_Series_Xaxis.Add(dt.Columns[counter].ColumnName);
                counter++;
            }

        }


        two_array = new string[1, ShipDetail.ShipDetailDashboard.Length];
        int counter1 = 0;

        for (int i = 0; i < ShipDetail.ShipDetailDashboard.Length; i++)
        {
            if (string.IsNullOrEmpty(txtLocation.Text))
            {
                if (ShipDetail.ShipDetailDashboard[i].LocationCode == System.Configuration.ConfigurationManager.AppSettings["loc1"])
                {
                    two_array[0, counter1] = ShipDetail.ShipDetailDashboard[i].ShippingAgent + "," + ShipDetail.ShipDetailDashboard[i].ShippingAgentService
                                  + "," + ShipDetail.ShipDetailDashboard[i].OrderNo;
                    counter1++;
                }
            }
            else if (ShipDetail.ShipDetailDashboard[i].LocationCode == txtLocation.Text)
            {
                two_array[0, counter1] = ShipDetail.ShipDetailDashboard[i].ShippingAgent + "," + ShipDetail.ShipDetailDashboard[i].ShippingAgentService
                                  + "," + ShipDetail.ShipDetailDashboard[i].OrderNo;
                counter1++;
            }

        }

        int jtemp = 0;
        int itemp = 0;
        bool isRushOrder = false;
        int temp_Count = 0;

        for (int i = 0; i < dt.Columns.Count; i++)
        {
            int temp = 0, temp1 = 0; temp_Count = 0; temp_rows_Count = 0;
            for (int j = 0; j < two_array.GetLength(0); j++)
            {
                jtemp = 0;
                if (two_array[j, i] != null)
                {
                    for (int k = 0; k < two_array.Length; k++)
                    {
                        if (two_array[itemp, jtemp] != null)
                        {
                            string[] Value = two_array[itemp, jtemp].Split(',');

                            if (Value[2].Contains("Rush Order"))
                            {
                                if (!string.IsNullOrWhiteSpace(two_array[j, i].ToString()))
                                {
                                    dt.Rows.Add();
                                    dt.Rows[temp1]["RUSH ORDER"] = Value[2]; //+(Value[4] != string.Empty ? " - " + Value[4] : "") + (Value[5] != string.Empty ? " - " + Value[5] : "");
                                    temp1++;
                                    temp_rows_Count++;
                                }
                                string Rush = Value[2];
                                if (dt.Columns[i].ColumnName == Line_Series_Xaxis[i] && Rush.ToUpper() == Line_Series_Xaxis[i])
                                {
                                    temp_Count++;
                                    temp_rows_Count++;
                                }
                                isRushOrder = true;
                            }
                            else
                            {
                                string Shp_Agnt_Srvc = Value[0] + (Value[1] != string.Empty ? " - " + Value[1] : "");

                                if (Shp_Agnt_Srvc.ToString() == "FEDEX - FEDEX")
                                    Shp_Agnt_Srvc = "FEDEX";
                                else if (Shp_Agnt_Srvc.ToString() == "CUSTPICKUP - CUST. PICKUP")
                                    Shp_Agnt_Srvc = "CUST. PICKUP";
                                else if (Shp_Agnt_Srvc.ToString() == "OWN LOG. - STANDARD")
                                    Shp_Agnt_Srvc = "OWN LOG.";
                                else if (Shp_Agnt_Srvc.ToString() == "USPS - USPS")
                                    Shp_Agnt_Srvc = "USPS";

                                if (Shp_Agnt_Srvc == dt.Columns[i].ColumnName)
                                {
                                    if (!string.IsNullOrWhiteSpace(two_array[j, i].ToString()))
                                    {
                                        dt.Rows.Add();
                                        dt.Rows[temp][dt.Columns[i].ColumnName] = Value[2]; //+(Value[4] != string.Empty ? " - " + Value[4] : "") + (Value[5] != string.Empty ? " - " + Value[5] : "");
                                        temp++;
                                        temp_rows_Count++;
                                    }
                                    if (dt.Columns[i].ColumnName == Line_Series_Xaxis[i])
                                    {
                                        temp_Count++;
                                        temp_rows_Count++;
                                    }
                                }
                            }
                            jtemp++;
                        }
                    }

                }
            }
            Line_Series_Yaxis.Add(temp_Count);
            list_str_count.Add(temp_rows_Count);
        }

        int RushOrderIndex = 0;
        bool Istrue = false;

        if (!isRushOrder)
        {
            for (int i = 0; i < Line_Series_Xaxis.Count; i++)
            {
                if (Line_Series_Xaxis[i] == "RUSH ORDER")
                {
                    Line_Series_Xaxis.Remove("RUSH ORDER");
                    dt.Columns.Remove("RUSH ORDER");
                    Istrue = true;
                    break;
                }
                RushOrderIndex = i;
            }

            if (Istrue)
            {
                Line_Series_Yaxis.RemoveAt(RushOrderIndex);
                list_str_count.RemoveAt(RushOrderIndex);
            }
        }

        if (!IsValideate)
        {
            #region Bar Chart

            string[] str_obj = Line_Series_Xaxis.ToArray();
            int[] inr = Line_Series_Yaxis.ToArray();

            object[] obj = Array.ConvertAll(inr, x => (object)x);

            Bar_Series = new List<Serie>();

            BarChart1.YAxis.Clear();
            BarChart1.XAxis.Clear();

            DataLabels dl = new DataLabels();
            dl.enabled = true;
            dl.color = "red";
            dl.x = 2;
            dl.y = 10;

            dl.style = new Highchart.Core.Appearance.CSSObject();
            dl.style.font = "Arial Black";
            dl.style.fontSize = "20px";
            dl.style.fontWeight = "900";

            BarChart1.PlotOptions = new PlotOptionsBar { dataLabels = dl, showInLegend = false };

            BarChart1.Colors = new Highchart.Core.Appearance.ColorSet();
            BarChart1.Colors.colors = new string[] { "Green" };

            BarChart1.Appearance = new Highchart.Core.Appearance.Appearance();
            BarChart1.Appearance.borderColor = "#E34335";
            //BarChart1.Appearance.borderRadius = 15;
            BarChart1.Appearance.borderWidth = 1;

            BarChart1.YAxis.Add(new YAxisItem { title = new Title("Number of Orders") });

            Labels lbl = new Labels();
            //lbl.style = new Highchart.Core.Appearance.CSSObject();
            //lbl.style.color = "Green";

            BarChart1.XAxis.Add(new XAxisItem { categories = str_obj, labels = lbl });
            Bar_Series.Add(new Serie { data = obj });

            if (BarChart1.XAxis.Count == 1 && BarChart1.YAxis.Count == 1)
            {
                BarChart1.XAxis[0].title = new Highchart.Core.Title("Carrier Options");
                BarChart1.XAxis[0].title.style = new Highchart.Core.Appearance.CSSObject();
                BarChart1.XAxis[0].title.style.color = "#0367B0";
                BarChart1.XAxis[0].title.style.font = "Arial Black";
                BarChart1.XAxis[0].title.style.fontSize = "25px";
                BarChart1.XAxis[0].title.style.fontWeight = "900";
                /* Services Styles */
                BarChart1.XAxis[0].labels.style = new Highchart.Core.Appearance.CSSObject();
                BarChart1.XAxis[0].labels.style.fontSize = "15px";
                BarChart1.XAxis[0].labels.style.font = "Arial Black";
                BarChart1.XAxis[0].labels.style.color = "magenta";
                BarChart1.XAxis[0].labels.x = -2;
                BarChart1.XAxis[0].labels.y = 7;

                BarChart1.YAxis[0].title = new Highchart.Core.Title("Number of Orders");
                BarChart1.YAxis[0].title.style = new Highchart.Core.Appearance.CSSObject();
                BarChart1.YAxis[0].title.style.color = "#0367B0";
                BarChart1.YAxis[0].title.style.font = "Aria Black";
                BarChart1.YAxis[0].title.style.fontSize = "25px";
                BarChart1.YAxis[0].title.style.fontWeight = "900";
            }

            BarChart1.DataSource = null;

            BarChart1.DataSource = Bar_Series;
            BarChart1.DataBind();

            #endregion
            //S
            #region Pie chart

            PieChart1.Title = new Title("Carrier Options");
            PieChart1.Title.style = new Highchart.Core.Appearance.CSSObject();
            PieChart1.Title.style.color = "#0367B0";
            PieChart1.Title.style.font = "Aria Black";
            PieChart1.Title.style.fontSize = "25";
            PieChart1.Title.style.fontWeight = "900";
            PieChart1.Appearance = new Highchart.Core.Appearance.Appearance();
            PieChart1.Appearance.borderColor = "#E34335";
            PieChart1.Appearance.borderWidth = 1;

            Pie_obj = new List<object>();
            for (int i = 0; i < Line_Series_Xaxis.Count; i++)
            {
                Pie_Data = new object[] { 
                Line_Series_Xaxis[i],
                Line_Series_Yaxis[i]
            };

                Pie_obj.Add(Pie_Data);
            }
            var P = Pie_obj.ToArray();
            Pie_Series = new List<Serie>();
            Pie_Series.Add(new Serie
            {
                size = 130,
                data = P
            });

            var objstyle = new Highchart.Core.Appearance.CSSObject();
            objstyle.font = "Arial Black";
            objstyle.fontSize = "20";
            objstyle.fontWeight = "900";

            PieChart1.PlotOptions = new PlotOptionsPie
            {
                allowPointSelect = true,
                cursor = "Pointer",
                showInLegend = true,
                dataLabels = new Highchart.Core.PlotOptions.DataLabels
                {
                    enabled = true,
                    formatter = "this.y",
                    style = objstyle
                },
            };


            PieChart1.Colors = new Highchart.Core.Appearance.ColorSet();
            //PieChart1.Colors.colors = new string[] { "red", "green", "blue", "yellow", "black", "chocolate", "Aqua", "BlueViolet", "Fuchsia", "LightSeaGreen", "MidnightBlue", "Olive", "DarkMagenta" };
            PieChart1.Colors.colors = new string[] { "#00FFFF", "#DAA520", "#0000FF", "#8A2BE2", "#A52A2A", "#008B8B", "#7FFF00", "#D2691E", "#6495ED", "#00008B", "#8B008B", "#2F4F4F", "green" };

            PieChart1.Tooltip = new ToolTip("'<b>'+ this.point.name +'</b>: '+ this.y +' '");

            //PieChart1.Tooltip = new ToolTip { formatter = "function() { return '<b>'+ this.point.name +'</b>: '+ this.percentage.toFixed(2) +' %'; }" };
            //PieChart1.PlotOptions.shadow = false;

            PieChart1.Theme = "skies";

            PieChart1.DataSource = Pie_Series;
            PieChart1.DataBind();

            #endregion
        }

        //GridView2.DataBound += new EventHandler(GridView2_DataBound);
        RemoveNullColumnFromDataTable(dt);

        GridView2.DataSource = dt;
        GridView2.DataBind();

    }

    public void RemoveNullColumnFromDataTable(DataTable dt)
    {
        int indexMax = !list_str_count.Any() ? -1 :
                  list_str_count.Select((value, index) => new { Value = value, Index = index }).Aggregate((a, b) => (a.Value > b.Value) ? a : b).Index;
        for (int i = dt.Rows.Count - 1; i >= 0; i--)
        {
            if (dt.Rows[i][indexMax] == DBNull.Value)
                dt.Rows[i].Delete();
        }
        dt.AcceptChanges();
    }

    private void GetDashboardDetails()
    {

        if (ShipHeader.ShipHeaderDashboard.Count() > 0)
        {
            #region test

            for (int i = 0; i < ShipHeader.ShipHeaderDashboard.Count(); i++)
            {
                if (string.IsNullOrEmpty(txtLocation.Text))
                {
                    if (ShipHeader.ShipHeaderDashboard[i].Location == System.Configuration.ConfigurationManager.AppSettings["loc1"])
                    {
                        txtLocation.Text = ShipHeader.ShipHeaderDashboard[i].Location;
                        txtdate.Text = ShipHeader.ShipHeaderDashboard[i].Date;
                        txtOrdrtoShip.Text = Convert.ToString(ShipHeader.ShipHeaderDashboard[i].OrdersToShip);
                        txtOrderShipped.Text = Convert.ToString(ShipHeader.ShipHeaderDashboard[i].OrdersShipped);
                        //txtOrdrPicked.Text = Convert.ToString(ShipHeader.ShipHeaderDashboard[i].OrdersPicked);
                    }
                }
                else if (ShipHeader.ShipHeaderDashboard[i].Location == txtLocation.Text)
                {
                    txtLocation.Text = ShipHeader.ShipHeaderDashboard[i].Location;
                    txtdate.Text = ShipHeader.ShipHeaderDashboard[i].Date;
                    txtOrdrtoShip.Text = Convert.ToString(ShipHeader.ShipHeaderDashboard[i].OrdersToShip);
                    txtOrderShipped.Text = Convert.ToString(ShipHeader.ShipHeaderDashboard[i].OrdersShipped);
                    //txtOrdrPicked.Text = Convert.ToString(ShipHeader.ShipHeaderDashboard[i].OrdersPicked);
                }
            }

            #endregion test
        }
    }

    protected void txtLocation_TextChanged(object sender, EventArgs e)
    {
        Session["shippinglocation"] = txtLocation.Text;
        Response.Redirect("OrdersShipping.aspx");
    }

    private void GetBindData()
    {
        string date = System.DateTime.Now.ToString("MM/dd/yy");
        //date = "10/01/2015..12/10/2015";
        objservice.ShipDashboard(ref ShipHeader, ref pickshp_root, ref ShipDetail, ref status);
        //Session["ShipHeaderDash"] = ShipHeader;
        //Session["ShpSrvcDash"] = pickshp_root;
        //Session["ShipDetailsDash"] = ShipDetail;
    }

    protected void GridView2_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            IsValideate = true;
            GridView2.PageIndex = e.NewPageIndex;
            Pie_Series = null;
            Bar_Series = null;
            GetDashboard_GridDetails();
            GetDashboardDetails();
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.alert('" + ex.Message + "');", true);
        }
    }

    protected void tmrRefreshChart_Tick(object sender, EventArgs e)
    {
        try
        {
            //GetBindData();
            //GetDashboardDetails();
            //GetDashboard_GridDetails();
        }
        catch (SoapException sx)
        {
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.alert('" + sx.Message + "');", true);
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.alert('" + ex.Message + "');", true);
        }

    }
}