﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WHDB;

public partial class Monthly_Shipped_Details : System.Web.UI.Page
{
    WarehouseDashboard objservice = new WarehouseDashboard();
    ShippedHeaderDashboardRoot SHDRoot = new ShippedHeaderDashboardRoot();
    private string username;
    private string password;
    int statusP = 0;

    List<int> loc1 = new List<int>();
    List<int> loc2 = new List<int>();
    List<string> Dates = new List<string>();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Username"] == null && Session["Password"] == null && Session["WHuser"] == null)
        {
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "myscript", "window.close();", true); return;
        }

        username = Session["Username"].ToString();
        password = Session["Password"].ToString();

        objservice.Credentials = new System.Net.NetworkCredential(username, password, System.Configuration.ConfigurationManager.AppSettings["Domain"]);

        if (!IsPostBack)
            BindData();
    }

    protected void Timer1_Tick(object sender, EventArgs e)
    {

         if (Session["OrderAnalysis"] as string == "true")
             Response.Redirect("Order_Analysis.aspx");
         else if (Session["EmployeeAnalysis"] as string == "true")
             Response.Redirect("Employee_Analysis.aspx");
         else if (Session["BatchAnalysis"] as string == "true")
             Response.Redirect("Batch_Analysis.aspx");
         else if (Session["PickCartAnalysis"] as string == "true")
             Response.Redirect("PickCart_Analysis.aspx");
         else if (Session["PickStatus"] as string == "true")
             Response.Redirect("PickStatus.aspx");
         else if (Session["PickedStatus"] as string == "true")
             Response.Redirect("PickedStatus.aspx");
         else if (Session["ShippingStatus"] as string == "true")
             Response.Redirect("OrdersShipping.aspx");
         else if (Session["ShippedStatus"] as string == "true")
             Response.Redirect("OrdersShipped.aspx");
         else if (Session["PickPerformance"] as string == "true")
             Response.Redirect("PickPerformance.aspx");
         else if (Session["PackPerformance"] as string == "true")
             Response.Redirect("PackPerformance.aspx");
         else if (Session["PickedGraph"] as string == "true")
             Response.Redirect("PickedStatusGraph.aspx");
         else if (Session["ShippedGraph"] as string == "true")
             Response.Redirect("ShippedStatusGraph.aspx");
         else if (Session["DailyPick"] as string == "true")
             Response.Redirect("Daily_Picked_Details.aspx");
         else if (Session["DailyShip"] as string == "true")
             Response.Redirect("Daily_Shipped_Details.aspx");
         else if (Session["MonthlyPick"] as string == "true")
             Response.Redirect("Montyly_Picked_Details.aspx");
         else
             Response.Redirect("Monthly_Shipped_Details.aspx");

    }

    private void BindData()
    {
        try
        {
            DateTime firstDay = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
            DateTime lastDay = firstDay.AddMonths(1).AddDays(-1);

            string date = firstDay.ToString("MM/dd/yy") + ".." + lastDay.ToString("MM/dd/yy");

            objservice.MonthlyShippedDashboard(date, ref SHDRoot, ref statusP);

            for (int i = 0; i < SHDRoot.ShippedHeaderDashboard.Length; i++)
            {
                if (!Dates.Contains(SHDRoot.ShippedHeaderDashboard[i].Date))
                    Dates.Add(SHDRoot.ShippedHeaderDashboard[i].Date);
            }

            for (int i = 0; i < Dates.Count; i++)
            {
                int counter1 = 0, counter2 = 0;
                for (int j = 0; j < SHDRoot.ShippedHeaderDashboard.Length; j++)
                {
                    for (int k = 0; k < SHDRoot.ShippedHeaderDashboard[j].ShippingServiceDashboard.Length; k++)
                    {
                        if (SHDRoot.ShippedHeaderDashboard[j].Date == Dates[i] && SHDRoot.ShippedHeaderDashboard[j].Location == System.Configuration.ConfigurationManager.AppSettings["loc1"])
                        {
                            counter1 += SHDRoot.ShippedHeaderDashboard[j].ShippingServiceDashboard[k].NoofOrders;
                        }
                        else if (SHDRoot.ShippedHeaderDashboard[j].Date == Dates[i] && SHDRoot.ShippedHeaderDashboard[j].Location == System.Configuration.ConfigurationManager.AppSettings["loc2"])
                        {
                            counter2 += SHDRoot.ShippedHeaderDashboard[j].ShippingServiceDashboard[k].NoofOrders;
                        }
                    }
                }
                loc1.Add(counter1);
                loc2.Add(counter2);
            }

            DotNet.Highcharts.Options.Series[] s = new DotNet.Highcharts.Options.Series[2];

            s[0] = new DotNet.Highcharts.Options.Series();
            s[0].Data = new DotNet.Highcharts.Helpers.Data(loc1.Cast<object>().ToArray());
            s[0].Type = DotNet.Highcharts.Enums.ChartTypes.Line;
            s[0].Name = System.Configuration.ConfigurationManager.AppSettings["loc1"];
            s[0].Color = System.Drawing.Color.Green;

            s[1] = new DotNet.Highcharts.Options.Series();
            s[1].Data = new DotNet.Highcharts.Helpers.Data(loc2.Cast<object>().ToArray());
            s[1].Type = DotNet.Highcharts.Enums.ChartTypes.Line;
            s[1].Name = System.Configuration.ConfigurationManager.AppSettings["loc2"];
            s[1].Color = System.Drawing.Color.Purple;


            DotNet.Highcharts.Highcharts chart = new DotNet.Highcharts.Highcharts("chart").SetXAxis(new DotNet.Highcharts.Options.XAxis { Categories = Dates.ToArray(), Labels = new DotNet.Highcharts.Options.XAxisLabels { Rotation = 300, Format = "<b>{value}</b>", Y = 35, Style = @"color: '#0033CC', fontSize: '14px',fontWeight: '900',fontFamily: 'Arial Black'" } })
            .SetSeries(s);

            chart.SetTitle(new DotNet.Highcharts.Options.Title { Style = @"fontSize: '30px', fontWeight: '900', fontFamily: 'Arial Black'", Margin = 100, Text = @"Comparison Monthly Shipped Status - <br/><b>" + System.DateTime.Now.ToString("MMMM", System.Globalization.CultureInfo.InvariantCulture).ToUpper() + " " + System.DateTime.Now.Year + "</b>" });

            DotNet.Highcharts.Options.Credits cr = new DotNet.Highcharts.Options.Credits();
            cr.Enabled = false;
            chart.SetCredits(cr);


            DotNet.Highcharts.Options.Legend legend = new DotNet.Highcharts.Options.Legend();
            legend.ItemStyle = @"fontSize: '25px',fontWeight: '900'";

            chart.SetLegend(legend);

            DotNet.Highcharts.Options.PlotOptions PO = new DotNet.Highcharts.Options.PlotOptions();
            PO.Line = new DotNet.Highcharts.Options.PlotOptionsLine();
            PO.Line.Cursor = DotNet.Highcharts.Enums.Cursors.Pointer;
            PO.Line.DataLabels = new DotNet.Highcharts.Options.PlotOptionsLineDataLabels();
            PO.Line.DataLabels.Enabled = true;
            PO.Line.DataLabels.Format = "<b>{y}</b>";
            PO.Line.DataLabels.Color = System.Drawing.Color.Red;
            //PO.Line.Color = System.Drawing.Color.Green;

            chart.SetPlotOptions(PO);

            DotNet.Highcharts.Options.YAxisTitle yaxis = new DotNet.Highcharts.Options.YAxisTitle();
            yaxis.Text = "No. of Orders";
            yaxis.Style = @"fontSize : '25px', fontWeight: '900', fontFamily: 'Arial Black'";

            chart.SetYAxis(new DotNet.Highcharts.Options.YAxis { Title = yaxis, Labels = new DotNet.Highcharts.Options.YAxisLabels { Y = 5, Format = "<b>{value}</b>", Style = @"color: '#0033CC', fontSize: '14px', fontWeight: '900', fontFamily: 'Arial Black'" } });

            ltrChart.Text = chart.ToHtmlString();

        }
        catch (Exception ex)
        {
            string msg = ex.Message.Replace("'", "");
            msg = msg.Replace("\n", "");
            //msg = msg + "\n";
            //lblErrorMsg.Text = msg;
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.alert('" + msg + "');", true);
        }
    }
}