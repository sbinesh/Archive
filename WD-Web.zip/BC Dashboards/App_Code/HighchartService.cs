﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using WHDB;
using Highchart.Core;
using Highchart.Core.PlotOptions;
using Highchart.Core.Data.Chart;
using System.Data;
using System.Web.Services.Protocols;

/// <summary>
/// Summary description for HighchartService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[System.Web.Script.Services.ScriptService]
public class HighchartService : System.Web.Services.WebService
{
    
    #region Variables

    int statusP = 0;
    WarehouseDashboard objservice = new WarehouseDashboard();

    List<string> objMonth;

    string username, password;


    #endregion

    public HighchartService()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 

        if (Session["Username"] != null && Session["Password"] != null && Session["WHuser"] != null)
        {
            username = Session["Username"].ToString();
            password = Session["Password"].ToString();
        }
        //else
        //{ System.Web.UI.ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "window.close();", true); return; }

    }

	#region Warehouse Employee Comparison

    [WebMethod(EnableSession = true)]
    public List<WHEmployee> WEmployee(string location)
    {

        if (string.IsNullOrEmpty(location))
            location = System.Configuration.ConfigurationManager.AppSettings["loc1"];

        PickHeaderDashboardRoot1 objPHDR = new PickHeaderDashboardRoot1();
        objservice.Credentials = new System.Net.NetworkCredential(username, password, System.Configuration.ConfigurationManager.AppSettings["Domain"]);

        DateTime firstDay = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1);
        DateTime lastDay = firstDay.AddMonths(1).AddDays(-1);
        string date = firstDay.ToString("MM/dd/yy") + ".." + lastDay.ToString("MM/dd/yy");

        objservice.OrderAnalysisDashboard(date, ref objPHDR, ref statusP);

        List<WHEmployee> objWHEmp = new List<WHEmployee>();
        List<int> objOP = new List<int>();
        List<int> objOR = new List<int>();
        List<int> objOS = new List<int>();
        List<int> objSO = new List<int>();
        objMonth = new List<string>();

        if (objPHDR.PickHeaderDashboard != null)
        {
            for (int i = 0; i < objPHDR.PickHeaderDashboard.Count(); i++)
            {
                if (objPHDR.PickHeaderDashboard[i].Location == location)
                {
                    objMonth.Add(objPHDR.PickHeaderDashboard[i].Date);
                    objOP.Add(objPHDR.PickHeaderDashboard[i].OrdersPicked);
                    objOR.Add(objPHDR.PickHeaderDashboard[i].OrdersReleased);
                    objOS.Add(objPHDR.PickHeaderDashboard[i].OrdersShipped);
                    objSO.Add(objPHDR.PickHeaderDashboard[i].SalesOrders);

                }
            }
        }

        for (int i = 0; i < objMonth.Count; i++)
            objWHEmp.Add(new WHEmployee { Location = location, ToDate = objMonth[i], OrdersPicked = objOP[i], OrdersReleased = objOR[i], OrdersShipped = objOS[i], SalesOrders = objSO[i] });

        return objWHEmp;
    }

    public class WHEmployee
    {
        public int OrdersPicked { get; set; }
        public int OrdersReleased { get; set; }
        public int OrdersShipped { get; set; }
        public int SalesOrders { get; set; }
        public string Location { get; set; }
        public string ToDate { get; set; }
    }

    #endregion


}
