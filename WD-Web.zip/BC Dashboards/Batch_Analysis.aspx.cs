﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WHDB;
using System.Data;

public partial class Batch_Analysis : System.Web.UI.Page
{
    WarehouseDashboard objservice = new WarehouseDashboard();
    BatchAnalysisDashboardRoot objPPD = new BatchAnalysisDashboardRoot();
    int statusP = 0;
    string dateP = "";

    string username, password;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["Username"] != null && Session["Password"] != null && Session["WHuser"] != null)
        {
            username = Session["Username"].ToString();
            password = Session["Password"].ToString();
        }
        else
        { ScriptManager.RegisterStartupScript(Page, this.GetType(), "myscript", "window.close();", true); return; }

        objservice.Credentials = new System.Net.NetworkCredential(username, password, System.Configuration.ConfigurationManager.AppSettings["Domain"]);
        if (!IsPostBack)
            BindData();
        //else
        //{
        //    if (Session["location"] != null)
        //        txtLocation.Text = Session["location"].ToString();
        //    if (Session["batch"] != null)
        //        txtbatch.Text = Session["batch"].ToString();
        //}
    }

    private void BindData()
    {
        try
        {
            dateP = System.DateTime.Now.ToString("MM/dd/yy");
            //dateP = "01/21/2016";

            if (Session["location"] != null)
                txtLocation.Text = Session["location"].ToString();
            if (Session["batch"] != null)
                txtbatch.Text = Session["batch"].ToString();

            objservice.BatchAnalysisDashboard(ref objPPD, ref statusP);
            string[] User;
            string User_ID = "";

            DataTable dt = new DataTable();

            dt.Columns.AddRange(
                            new DataColumn[5] 
                            { 
                            new DataColumn("Location", typeof(string)),
                            new DataColumn("Batch Code", typeof(string)),
                            new DataColumn("PickNo", typeof(string)),
                            new DataColumn("UserID", typeof(string)),
                            new DataColumn("Status",typeof(string))
                            });
            if (objPPD.BatchAnalysisDashboard != null)
            {
                for (int i = 0; i < objPPD.BatchAnalysisDashboard.Count(); i++)
                {

                    if (objPPD.BatchAnalysisDashboard[i].UserID.Contains('\\'))
                    {
                        User = objPPD.BatchAnalysisDashboard[i].UserID.Split('\\');
                        User_ID = User[1];
                    }
                    else
                        User_ID = objPPD.BatchAnalysisDashboard[i].UserID;

                    if (Session["batch"] != null && !string.IsNullOrEmpty(txtbatch.Text))
                    {
                        if (txtbatch.Text.ToUpper() == objPPD.BatchAnalysisDashboard[i].BatchCode.ToUpper())
                        {
                            if (Session["location"] != null && !string.IsNullOrEmpty(txtLocation.Text))
                            {
                                if (txtLocation.Text.ToUpper() == objPPD.BatchAnalysisDashboard[i].Location.ToUpper())
                                {
                                    dt.Rows.Add(
                                objPPD.BatchAnalysisDashboard[i].Location,
                                Convert.ToString(objPPD.BatchAnalysisDashboard[i].BatchCode),
                                Convert.ToString(objPPD.BatchAnalysisDashboard[i].PickNo),
                                User_ID,
                                Convert.ToString(objPPD.BatchAnalysisDashboard[i].Status)
                                );
                                }
                            }
                            else
                            {
                                dt.Rows.Add(
                                objPPD.BatchAnalysisDashboard[i].Location,
                                Convert.ToString(objPPD.BatchAnalysisDashboard[i].BatchCode),
                                Convert.ToString(objPPD.BatchAnalysisDashboard[i].PickNo),
                                User_ID,
                                Convert.ToString(objPPD.BatchAnalysisDashboard[i].Status)
                                );
                            }
                        }
                        
                    }
                    else if (Session["location"] != null && !string.IsNullOrEmpty(txtLocation.Text))
                    {
                        if (txtLocation.Text.ToUpper() == objPPD.BatchAnalysisDashboard[i].Location.ToUpper())
                        {
                            dt.Rows.Add(
                        objPPD.BatchAnalysisDashboard[i].Location,
                        Convert.ToString(objPPD.BatchAnalysisDashboard[i].BatchCode),
                        Convert.ToString(objPPD.BatchAnalysisDashboard[i].PickNo),
                        User_ID,
                        Convert.ToString(objPPD.BatchAnalysisDashboard[i].Status)
                        );
                        }
                    }
                    else
                    {
                        dt.Rows.Add(
                        objPPD.BatchAnalysisDashboard[i].Location,
                        Convert.ToString(objPPD.BatchAnalysisDashboard[i].BatchCode),
                        Convert.ToString(objPPD.BatchAnalysisDashboard[i].PickNo),
                        User_ID,
                        Convert.ToString(objPPD.BatchAnalysisDashboard[i].Status)
                        );
                    }
                }
            }

            gvWE.DataSource = dt;
            gvWE.DataBind();

        }
        catch (Exception ex)
        {
            Response.Write(ex.Message);
        }
    }

    public class Batch
    {
        public string Location { get; set; }
        public string BatchCode { get; set; }
        public int PickNo { get; set; }
        public int Employee { get; set; }
        public int Status { get; set; }
    }

    protected void GridView2_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            gvWE.PageIndex = e.NewPageIndex;
            BindData();
        }
        catch (Exception ex)
        {
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.alert('" + ex.Message + "');", true);
        }
    }

    protected void Timer1_Tick(object sender, EventArgs e)
    {
        if (Session["PickCartAnalysis"] as string == "true")
            Response.Redirect("PickCart_Analysis.aspx");
        else if (Session["PickStatus"] as string == "true")
            Response.Redirect("PickStatus.aspx");
        else if (Session["PickedStatus"] as string == "true")
            Response.Redirect("PickedStatus.aspx");
        else if (Session["ShippingStatus"] as string == "true")
            Response.Redirect("OrdersShipping.aspx");
        else if (Session["ShippedStatus"] as string == "true")
            Response.Redirect("OrdersShipped.aspx");
        else if (Session["PickPerformance"] as string == "true")
            Response.Redirect("PickPerformance.aspx");
        else if (Session["PackPerformance"] as string == "true")
            Response.Redirect("PackPerformance.aspx");
        else if (Session["PickedGraph"] as string == "true")
            Response.Redirect("PickedStatusGraph.aspx");
        else if (Session["ShippedGraph"] as string == "true")
            Response.Redirect("ShippedStatusGraph.aspx");
        else if (Session["DailyPick"] as string == "true")
            Response.Redirect("Daily_Picked_Details.aspx");
        else if (Session["DailyShip"] as string == "true")
            Response.Redirect("Daily_Shipped_Details.aspx");
        else if (Session["MonthlyPick"] as string == "true")
            Response.Redirect("Montyly_Picked_Details.aspx");
        else if (Session["MonthlyShip"] as string == "true")
            Response.Redirect("Monthly_Shipped_Details.aspx");
        else if (Session["OrderAnalysis"] as string == "true")
            Response.Redirect("Order_Analysis.aspx");
        else if (Session["EmployeeAnalysis"] as string == "true")
            Response.Redirect("Employee_Analysis.aspx");
        else
            Response.Redirect("Batch_Analysis.aspx");

    }

    protected void submit_Click(object sender, EventArgs e)
    {
        Session["location"] = txtLocation.Text;
        Session["batch"] = txtbatch.Text;
        BindData();
    }
    protected void txtLocation_TextChanged(object sender, EventArgs e)
    {
        Session["location"] = txtLocation.Text;
        BindData();
    }
    protected void txtbatch_TextChanged(object sender, EventArgs e)
    {
        Session["batch"] = txtbatch.Text;
        BindData();
    }
}