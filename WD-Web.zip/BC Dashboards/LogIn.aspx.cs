﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Lookups;

public partial class Authrizedfrm : System.Web.UI.Page
{
    UserID_Service UsrSrvc = new UserID_Service();
    UserID user = new UserID();
    UserID_Filter fil = new UserID_Filter();
    List<UserID_Filter> filter = new List<UserID_Filter>();

    protected void Page_Load(object sender, EventArgs e)
    {
        //lblErrorMsg.Text = "";
    }
    protected void LoginUser_Authenticate(object sender, AuthenticateEventArgs e)
    {
        try
        {
            Session["Username"] = null;
            Session["Password"] = null;
            Session["WHuser"] = null;
            UsrSrvc.Credentials = new System.Net.NetworkCredential(LoginUser.UserName, LoginUser.Password, System.Configuration.ConfigurationManager.AppSettings["Domain"]);
            //user = UsrSrvc.Read(LoginUser.UserName);
            user = UsrSrvc.Read(System.Configuration.ConfigurationManager.AppSettings["Domain"] + "\\" + LoginUser.UserName);
            if (user != null)
            {
                if(user.WD_Application_Allowed)
                {
                    Session["Username"] = LoginUser.UserName;
                    Session["Password"] = LoginUser.Password;
                    Session["WHuser"] = user.WD_Application_Allowed;
                    Response.Redirect("Mainmenu.aspx");
                }
                else
                {
                    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.alert('You do not have permission to accessDashboard Application. Please contact your manager to have your permissions changed');", true);
                    return;
                }
            }
            else
            {
                ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.alert('User does not Exists');", true);
                return;
            }
        }
        catch (System.Web.Services.Protocols.SoapException ex)
        {
            string msg = ex.Detail.InnerText.Replace("'", "");
            msg = msg.Replace("\n", "");
            //msg = msg + "\n";
            //lblErrorMsg.Text = msg;
            ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.alert('" + msg + "');", true);
        }
        //catch (Exception ex)
        //{
        //    ScriptManager.RegisterStartupScript(Page, this.GetType(), "alert", "window.alert('Invalid User Name or Password');", true);
        //}
    }
}