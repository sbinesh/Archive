﻿//jQuery(document).ready(function () {
//    // Instantiate jTicker 
//    jQuery("#ticker").ticker({
//        cursorList: " ",
//        rate: 10,
//        delay: 4000
//    }).trigger("play").trigger("stop");

//    window.setInterval('test()', 3000);
//    right();
//    jQuery(".style").click(function () {
//        jQuery("#ticker")
//        .trigger({
//            type: "control",
//            cursor: jQuery("#ticker").data("ticker").cursor.css({ width: "4em", background: "#efefef", position: "relative", top: "1em", left: "-1em" })
//        })
//        return false;
//    });

//});

function right() {
    document.oncontextmenu = new Function("return false")
}

//function test() {
//    jQuery("#ticker").trigger("play");
//    return false;
//}
//
$(function () {
    $('.fadein img:gt(0)').hide();
    setInterval(function () { $('.fadein :first-child').fadeOut().next('img').fadeIn().end().appendTo('.fadein'); }, 3000);
});